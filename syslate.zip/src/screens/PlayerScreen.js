import React, { useEffect, useState, useRef, useCallback, useMemo, startTransition } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions, Image, Animated, Easing, AppState } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { playerArtUri } from '../utils/embeddedArt';
import AudioEngine, { useProgress, usePlaybackState, matchProgress, peekLastProgress, State } from '../native/AudioEngine';
import { useNavigation, useRoute } from '@react-navigation/native';
import { usePlayback } from '../context/PlaybackContext';
import { useLibrary } from '../context/LibraryContext';
import { usePreferences } from '../context/PreferencesContext';
import { formatArtists } from '../utils/artists';
import { getLyrics, activeLyricIndex, peekLyrics } from '../utils/lyrics';
import { useTheme } from '../context/ThemeContext';
import { skipWithRamp, playWithRamp, pauseWithRamp, isTransitionLocked, forceReleaseFade } from '../services/PlaybackService';
import { PlayIcon, PauseIcon, SkipNextIcon, SkipPrevIcon, ShuffleIcon, LoopIcon, MenuBarsIcon, MoonIcon } from '../components/Icons';
import SleepTimerSheet from '../components/SleepTimerSheet';
import { PanGestureHandler, TapGestureHandler, State as GHState } from 'react-native-gesture-handler';
import EQModal from '../components/EQModal';
import QueueModal from '../components/QueueModal';
import ScreenBackground from '../components/ScreenBackground';
import GradientCap from '../components/GradientCap';
import DJDisc from '../components/DJDisc';
import PlaybackSpeedSheet, { formatSpeed } from '../components/PlaybackSpeedSheet';
import { squircle, cardRadius } from '../utils/squircle';
import SongVisualizer from '../components/SongVisualizer';
import { mixHex } from '../utils/color';
import { getPlayCounts, peekPlayCount, playCountKey, playCountKeyN, subscribePlayCount } from '../utils/storage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { TOP_PAD } from '../utils/layout';

const { width } = Dimensions.get('window');

// The elapsed time. The player is only asked for its position every half
// second, so the seconds used to run up to half a second behind the lock
// screen's. This carries the last reading forward in real time (in its own
// small component, so the whole screen is not redrawn for it) and never lets
// the number step backwards when the next reading arrives.
const LiveTime = React.memo(function LiveTime({ position, duration, playing, rate, style }) {
    const basis = useRef({ position, at: Date.now() });
    const shown = useRef(position);
    const [, tick] = useState(0);
    // `playing` is part of this on purpose: while paused the position prop
    // stops changing, so without it the basis stayed frozen at the last
    // movement and the first render after resuming counted every paused
    // minute as playback, the clock snapped to the end of the song for the
    // half second until the next reading arrived.
    useEffect(() => { basis.current = { position, at: Date.now() }; }, [position, playing]);
    useEffect(() => {
        if (!playing) return undefined;
        const t = setInterval(() => tick(x => x + 1), 200);
        return () => clearInterval(t);
    }, [playing]);
    let p = position;
    if (playing) {
        p = basis.current.position + ((Date.now() - basis.current.at) / 1000) * (rate || 1);
        if (duration > 0) p = Math.min(p, duration);
        if (p < shown.current && shown.current - p < 1.2 && position >= shown.current - 1.5) p = shown.current;
    }
    shown.current = p;
    return <Text style={style}>{fmt(p)}</Text>;
});

function fmt(sec) {
    // A position a hair below zero (a song just starting) used to print as "-1:-1".
    if (!sec || isNaN(sec) || sec < 0) return '0:00';
    return `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
}

// Note: the swipe-down-to-close gesture is now handled entirely by
// React Navigation's built-in modal transition (see App.js — gestureEnabled +
// TransitionPresets.ModalSlideFromBottomIOS) instead of a hand-rolled
// PanResponder here. That hand-rolled version was fighting with the
// navigator's own transition (causing the blank-flash-then-double-swipe bug)
// and, being JS-thread-only, never felt as smooth as the library's own
// gesture-handler-backed implementation.
// A gray/neutral accent (white, silver, gray) is nearly the same color as the
// dim gray the non-playing lyric lines use, so the current line couldn't be
// told apart. For those accents the current line uses the full-strength text
// color and the rest drop to the faintest gray, so the contrast is always there.
function isNeutralColor(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec((hex || '').trim());
    if (!m) return false;
    const n = parseInt(m[1], 16);
    const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return Math.max(r, g, b) - Math.min(r, g, b) < 28;
}

const LYRIC_CARRY_MAX_SEC = 1.0;   // readings come every 0.5 s; never run further than this past one

export default function PlayerScreen() {
    const navigation = useNavigation();
    const route = useRoute();
    const { playlist } = route.params ?? {};
    const { theme, base } = useTheme();
    const insets = useSafeAreaInsets();
    const lyricNeutral = isNeutralColor(theme.accent);
    const lyricActiveColor = lyricNeutral ? base.text : theme.accent;
    const lyricIdleColor = lyricNeutral ? base.textFaint : base.textDim;
    // Turned-off buttons (shuffle, loop, sleep timer, speed at 1x) get their own color, clearly
    // further from the "on" color than the artist / small text gray (base.textFaint), which stays
    // as it is. Dark themes: darker than that gray. Light themes: lighter.
    const offColor = mixHex(base.textFaint, base.bg, 0.5);

    const {
        currentPlaylist, queueSource, playbackRate, currentTrack, shuffleOn, singleLoop, libraryFor,
        loadPlaylist, toggleShuffle, toggleSingleLoop,
        sleepTimerEndAt, sleepAtTrackEnd,
    } = usePlayback();
    // Last resort for the top label: a song that is not in the loaded playlist and has no
    // remembered source (e.g. queued before the app was last restarted) is named after a
    // playlist that contains it, instead of a generic "Now Playing".
    const { playlists: libraryPlaylists } = useLibrary();
    const curId = currentTrack?.id;
    const homePlaylistName = React.useMemo(() => {
        if (!curId || !Array.isArray(libraryPlaylists)) return null;
        for (const p of libraryPlaylists) {
            if (p?.songs?.some(x => x.id === curId)) return p.name;
        }
        return null;
    }, [curId, libraryPlaylists]);

    // The length of the song as remembered from an earlier reading, shown while the player has not reported one yet
    // (right after a tap the time used to read 0:00 / 0:00 for about a second).
    const [knownDur, setKnownDur] = useState(0);
    useEffect(() => {
        let c = false;
        setKnownDur(0);
        if (!currentTrack) return undefined;
        AsyncStorage.getItem('pdur:' + playCountKey(currentTrack).slice(4)).then(v => { if (!c) setKnownDur(parseFloat(v) || 0); }).catch(() => { });
        return () => { c = true; };
    }, [currentTrack?.id]);
    const rawProgress = useProgress(500);
    // Only readings that belong to the song being shown count (a late reading
    // from before a skip used to drag the bar to the old song's spot).
    const progress = useMemo(
        () => matchProgress(rawProgress, currentTrack?._qid, currentTrack?.duration || knownDur, currentTrack?.id),
        [rawProgress, currentTrack?._qid, currentTrack?.duration, currentTrack?.id, knownDur]
    );
    // Only true right after the CURRENTLY-PLAYING track actually changes —
    // not on every mount. Before, this effect fired on mount regardless of
    // whether currentTrack.id had genuinely changed (that's just how effects
    // work on the dependency they're given), which is why opening the player
    // — even mid-song — briefly showed 0:00 before jumping to the real
    // position. prevTrackIdRef starts equal to the first render's id, so the
    // mount case is a no-op; only a later, real change fires this.
    const prevTrackIdRef = useRef(currentTrack?.id);
    const [justSwitched, setJustSwitched] = useState(false);
    // Where the new song really is right after a change (a crossfade flips the
    // display halfway, so it is already a few seconds in), so the time and bar
    // start there instead of at 0:00 and jumping.
    const [switchProg, setSwitchProg] = useState({ position: 0, duration: 0 });
    useEffect(() => {
        if (prevTrackIdRef.current === currentTrack?.id) return;
        prevTrackIdRef.current = currentTrack?.id;
        setSwitchProg({ position: 0, duration: 0 });
        setJustSwitched(true);
        const t = setTimeout(() => setJustSwitched(false), 400);
        return () => clearTimeout(t);
    }, [currentTrack?.id]);
    const playbackState = usePlaybackState();
    const isPlaying = playbackState.state === State.Playing;

    // const [showEQ, setShowEQ] = useState(false); // EQ hidden
    const [showQueue, setShowQueue] = useState(false);
    const [showSleepTimer, setShowSleepTimer] = useState(false);
    const [showSpeed, setShowSpeed] = useState(false);
    // Two-line titles grow UPWARD from the one-line position, so nothing else
    // on the Player moves. titleLines/titleLineH come from the title's own
    // layout and only drive how far the Show Lyrics/Disc button lifts.
    const [titleLines, setTitleLines] = useState(1);
    const [titleLineH, setTitleLineH] = useState(27);
    const [showEQ, setShowEQ] = useState(false);
    const [pc, setPc] = useState({ id: null, n: 0 });
    // This used to be its own local `useState(true)`, loaded once on mount
    // via getShowPlayCount() and never touched again — every OTHER screen
    // (All Songs, Playlist Detail, Queue) reads this from the shared
    // PreferencesContext specifically so a toggle in Settings reaches an
    // already-mounted screen immediately (see that context's own comment).
    // Player being the one screen that kept its own stale local copy meant
    // it just wouldn't notice a toggle flip while already open — since
    // Player tends to stay mounted for the whole session, this is likely
    // why play count looked "off" here even after confirming the actual
    // preference was on.
    const { playerVizCover, playerVizBehind, performanceMode, showPlayCount, artistSeparator, lyricsResyncSec, lyricsOffsetSec, lyricsGapSec, lyricsArrows, coverShape, showPlayerCover, coverShadow, lyricsScrollLocked, artistDisplayJoin, lyricsMode, djDisc, djDiscType, djDiscAssist, djDiscSpin, djDiscTouch, autoShowLyrics, autoShowDisc, discRpmValue, playerOutline, playerBtns, crossfadeEnabled, crossfadeDuration, crossfadeDurationEndOfTrack } = usePreferences();

    // The count is credited once a song passes half way, so the shown count is read again
    // at that moment (it used to stay stale until the next song). The `cancelled` flag stops a
    // slow read for the previous song from landing on the new one after a quick skip.
    const pastHalf = progress.duration > 0 && progress.position / progress.duration >= 0.5;
    // Where the visualizer behind the controls starts: halfway between the bottom of the cover and the top of the title.
    // The cover, the title group and the title row each report their own position inside their parent;
    // the pieces are added up here once all four are known.
    const [vizTop, setVizTop] = useState(null);
    const vizLay = useRef({ artBottom: null, wrapY: null, groupY: null, infoY: null });
    const recomputeVizTop = () => {
        const l = vizLay.current;
        if (l.artBottom == null || l.wrapY == null || l.groupY == null || l.infoY == null) return;
        const titleTop = l.wrapY + l.groupY + l.infoY;
        const top = Math.max(0, Math.round((l.artBottom + titleTop) / 2));
        setVizTop(prev => (prev === top ? prev : top));
    };
    useEffect(() => {
        if (!currentTrack?.id) { setPc({ id: null, n: 0 }); return; }
        let cancelled = false;
        const id = currentTrack.id;
        const t = setTimeout(() => {
            // Looked up with the library's copy of the song, the same one the lists use, so the number here
            // and the number in the list are always the same one.
            const lib = (libraryFor && libraryFor(currentTrack)) || currentTrack;
            getPlayCounts([lib]).then(counts => { if (!cancelled) setPc({ id, n: counts[lib.id] ?? 0 }); });
        }, pastHalf ? 400 : 0);
        return () => { cancelled = true; clearTimeout(t); };
    }, [currentTrack?.id, pastHalf, libraryFor]);

    // Show the new count the moment this song's play is counted.
    useEffect(() => subscribePlayCount(({ key, n, counts, reset }) => {
        if (reset) { if (currentTrack?.id) setPc({ id: currentTrack.id, n: 0 }); return; }
        const lib = (libraryFor && libraryFor(currentTrack)) || currentTrack;
        if (counts) {
            const hit = [playCountKey(lib), playCountKeyN(lib)].find(k => counts[k] !== undefined);
            if (currentTrack?.id && hit !== undefined) setPc({ id: currentTrack.id, n: counts[hit] });
            return;
        }
        if (currentTrack?.id && (playCountKey(lib) === key || playCountKeyN(lib) === key)) setPc({ id: currentTrack.id, n });
    }), [currentTrack, libraryFor]);

    const shownCount = pc.id === currentTrack?.id ? pc.n : (peekPlayCount(currentTrack?.id) ?? 0);
    const progressRef = useRef(null);
    const controlsRef = useRef(null);
    const progressLayout = useRef({ pageX: 28, width: width - 56 });
    const [dragRatio, setDragRatio] = useState(null);
    const [barW, setBarW] = useState(width - 56);
    const seekChainRef = useRef(Promise.resolve());
    const latestSeekRatioRef = useRef(null);
    const clearDragTimer = useRef(null);
    const committedRef = useRef(false);
    const gestureTrackIdRef = useRef(null);
    // Real cause of "the progress bar moves with my taps/drags but never
    // actually seeks, then snaps back" (no [SEEK-DEBUG] line ever appeared
    // in a real capture — the commit was being dropped BEFORE reaching
    // seekTo): the gesture handlers below are created once (useRef(...)
    // .current, deliberately, to stay referentially stable mid-gesture) so
    // anything they read directly from render scope is frozen at whatever
    // it was on the FIRST render. gestureTrackIdRef was being set from that
    // frozen currentTrack, while onScrub's "did the track change while you
    // were dragging?" check compares it against the CURRENT one — so as
    // soon as the playing track differed from whatever was loaded when this
    // screen first mounted, every seek got dropped as "track changed under
    // us". Taps were worse: they never set gestureTrackIdRef at all (null
    // -> always "changed") and never reset committedRef either. This ref is
    // refreshed every render, so the stable handlers can read it fresh.
    const nowTrackIdRef = useRef(currentTrack?._qid ?? currentTrack?.id ?? null);
    nowTrackIdRef.current = currentTrack?._qid ?? currentTrack?.id ?? null;
    // Set whenever the lyrics view's active line is about to move for a
    // reason OTHER than natural playback advancing one line at a time — a
    // manual seek (below) or a track change (see the lyrics reset effect
    // further down). Both are "jumps": the correct line could be anywhere
    // in the list, so the scroll should SNAP straight there, not animate
    // through everything in between the way a normal line-to-line advance
    // does. Consumed (and cleared) by the scroll-to-line effect itself.
    const lyricsJustJumpedRef = useRef(false);
    // Set on commit to the ratio we just asked the native side to seek to;
    // cleared once the polled position actually agrees (see the
    // convergence effect below) rather than on a fixed timer. See onScrub's
    // commit branch for why the fixed timer this replaced caused a visible
    // "jumps back" glitch.
    const pendingSeekRatioRef = useRef(null);
    // See the dedup check in onScrub's commit branch — tracks the last
    // ratio/time a native seekTo actually fired for.
    const lastNativeSeekRef = useRef({ ratio: -1, at: 0 });
    // Backstop: if no terminal gesture state ever arrives after a touch
    // starts (this has been the recurring symptom — the bar freezes and
    // STAYS frozen, even across later songs, only unstuck by a real drag),
    // force a commit anyway after 500ms so a touch can never leave dragRatio
    // stuck forever. This doesn't depend on correctly diagnosing which
    // gesture-handler state transition is or isn't firing.
    const stuckSafetyTimer = useRef(null);
    const lastTouchX = useRef(0);

    // One continuous animation running at the song's actual real-time rate,
    // instead of a new mini-animation restarted on every progress hook tick.
    // Restarting on every tick was the real source of both the choppiness
    // and the post-release jump: a fixed-duration animation racing a
    // variable real-time gap between ticks necessarily drifts, and canceling
    // an in-flight animation to start another one is visually a stutter.
    const animPct = useRef(new Animated.Value(
        progress.duration > 0 ? progress.position / progress.duration : 0
    )).current;
    const animRunRef = useRef(null);
    const animPctValueRef = useRef(progress.duration > 0 ? progress.position / progress.duration : 0); // the bar's value when it is not running
    // The bar runs as a native animation (it keeps moving smoothly even when
    // the JS thread is busy, e.g. right after Play or a skip), so its current
    // value is worked out from when it started instead of read back.
    const barRun = useRef(null);          // { from, at, rate } while it runs
    const barGraceUntil = useRef(0);      // right after a start the audio position is still settling
    const barPctNow = () => {
        const r = barRun.current;
        if (!r) return animPctValueRef.current;
        return Math.min(1, r.from + ((Date.now() - r.at) / 1000) * r.rate);
    };

    const stopAnim = () => {
        if (barRun.current) { animPctValueRef.current = barPctNow(); barRun.current = null; }
        animRunRef.current?.stop();
        animRunRef.current = null;
    };

    // `durOverride`: the song's real length when the caller knows it better than `progress` (right after a song
    // change `progress` can still hold the old song's length, which made the bar run too fast until the next poll).
    const startRealTimeAnim = (fromPct, grace = false, durOverride = 0) => {
        stopAnim();
        animPct.setValue(fromPct);
        animPctValueRef.current = fromPct;
        if (grace) barGraceUntil.current = Date.now() + 2500;
        const dur = durOverride > 0 ? durOverride : progress.duration;
        if (!isPlaying || dur <= 0 || fromPct >= 1) return;
        // Real time to the end = remaining song time / playback speed.
        const remainingMs = Math.max(0, ((1 - fromPct) * dur * 1000) / (playbackRate || 1));
        barRun.current = { from: fromPct, at: Date.now(), rate: (playbackRate || 1) / dur };
        const anim = Animated.timing(animPct, { toValue: 1, duration: remainingMs, easing: Easing.linear, useNativeDriver: true });
        animRunRef.current = anim;
        anim.start();
    };

    const measureProgress = () => {
        progressRef.current?.measure((_x, _y, w, _h, pageX) => {
            if (w > 0) progressLayout.current = { pageX, width: w };
        });
    };

    const touchToRatio = (pageX) => Math.max(0.002, Math.min(0.99,
        (pageX - progressLayout.current.pageX) / progressLayout.current.width
    ));

    const onScrub = (absoluteX, commit) => {
        lastTouchX.current = absoluteX;
        const ratio = touchToRatio(absoluteX);
        setDragRatio(ratio);
        stopAnim();
        animPct.setValue(ratio);
        animPctValueRef.current = ratio;

        if (!commit) {
            // Visual feedback only — nothing is seeked until release, so
            // audio keeps playing from wherever it actually is while
            // dragging. Re-arms the stuck-safety backstop on every update
            // (not just once at BEGAN) so it's a true "500ms since
            // anything last happened" watchdog rather than a fixed timeout
            // from touch-start, which used to fire mid-drag on any gesture
            // that simply took longer than 500ms start-to-finish.
            clearTimeout(stuckSafetyTimer.current);
            stuckSafetyTimer.current = setTimeout(() => {
                onScrubRef.current(lastTouchX.current, true);
            }, 500);
            return;
        }

        // Commit — release, a tap, or the stuck-safety backstop. Only
        // fires once per gesture: without this guard, a real release
        // landing right after the safety backstop already fired would
        // seek twice to (almost) the same spot.
        if (committedRef.current) { console.log('[SEEK-DEBUG] commit ignored: already committed this gesture'); if (pendingSeekRatioRef.current === null) setDragRatio(null); return; }
        committedRef.current = true;
        clearTimeout(stuckSafetyTimer.current);

        startRealTimeAnim(ratio);
        clearTimeout(clearDragTimer.current);

        // Abuse case flagged explicitly: held long enough that the track
        // actually changed under us (natural end-of-track, a remote skip,
        // etc.) while still dragging — the position being released at no
        // longer corresponds to whatever's playing now, so drop the seek
        // instead of applying it to the wrong track.
        const nowTrackId = currentTrack?._qid ?? currentTrack?.id ?? null;
        if (nowTrackId !== gestureTrackIdRef.current) { console.log('[SEEK-DEBUG] commit dropped: track id mismatch', { nowTrackId, gesture: gestureTrackIdRef.current }); setDragRatio(null); return; }

        if (progress.duration > 0) {
            const targetRatio = ratio;
            const duration = progress.duration;
            // Moved ahead of everything below (was only guarding the final
            // seekTo call) — now also guards the isTransitionLocked()
            // interrupt-cleanup just below. Best working theory for BOTH
            // this and the double-audio bug: a real pan-gesture release can
            // apparently still be followed by a spurious extra BEGAN→END
            // from the simultaneous tap handler at the same position (see
            // realDragMovedRef's comment elsewhere in this file for the
            // general fragility here), which resets committedRef for what
            // LOOKS like a fresh gesture and lets a second, redundant
            // commit through to the same spot. That second commit's own
            // isTransitionLocked() cleanup (forceReleaseFade +
            // setVolume(1)) firing a beat later — possibly after the user
            // has already tapped Play and a fresh ramp-in has started —
            // would forcibly kill that ramp and slam volume to 1, matching
            // "swipe while paused, hit play, doesn't ramp." Bailing out
            // this early means a redundant commit does nothing at all
            // instead of just skipping the seek call.
            const now = Date.now();
            if (Math.abs(targetRatio - lastNativeSeekRef.current.ratio) < 0.005 && now - lastNativeSeekRef.current.at < 800) {
                console.log('[SEEK-DEBUG] commit skipped: same spot as the seek just made');
                if (pendingSeekRatioRef.current === null) setDragRatio(null);   // otherwise the time text stayed frozen at this spot
                return;
            }
            lastNativeSeekRef.current = { ratio: targetRatio, at: now };
            latestSeekRatioRef.current = targetRatio;
            // A seek can land the active lyric line anywhere — see
            // lyricsJustJumpedRef's declaration for why that means the
            // lyrics scroll-to-line effect should snap instead of animate.
            lyricsJustJumpedRef.current = true;
            // "Double-plays when sliding the bar" with ramping on: seekTo
            // never checked for an in-flight ramp before running. Native
            // seekTo reschedules and immediately resumes playback at
            // whatever volume the node is CURRENTLY at (mid-fade, e.g.
            // 0.4) — but the JS ramp timer that was already running had no
            // idea a seek just happened, and kept firing its own volume
            // steps / its own eventual pause() on top of the freshly
            // resumed audio. Releasing the fade lock (its remaining steps
            // check ownership before touching volume, so this makes them
            // no-op cleanly — see forceReleaseFade above) and restoring
            // full volume before the seek lands means there's exactly one
            // thing driving playback state through a seek, not two.
            // A fade (play ramp-in or pause ramp-out) that is running keeps
            // running: the seek moves the song position underneath it, the
            // bar shows the new spot at once, and the fade finishes on its
            // own (a pause ramp still ends in the pause). It used to cut the
            // fade and set the volume to full, which left a pause half done.
            if (isTransitionLocked()) console.log('[SEEK-DEBUG] seek during a fade: fade left running');
            // Was: clearDragTimer fired unconditionally 300ms after commit,
            // regardless of whether this seek had actually landed natively
            // yet. Once dragRatio cleared, the drift-correction effect
            // re-armed immediately — and if the polled position (500ms
            // interval) hadn't caught up to the seek yet, it read that
            // STALE pre-seek position as "drift" and snapped the bar back
            // to it, then snapped forward again once the next poll finally
            // agreed. That's the "shows the movement but then jumps back"
            // symptom. Now dragRatio stays held (bar shows the target
            // position) until the polled position actually agrees — see
            // the convergence effect below — with this timer only as a
            // backstop in case a seek silently fails to land.
            pendingSeekRatioRef.current = targetRatio;
            clearDragTimer.current = setTimeout(() => {
                pendingSeekRatioRef.current = null;
                setDragRatio(null);
            }, 2500);
            // [SEEK-DEBUG] Temporary — same pattern as [RAMP-DEBUG]. Reported:
            // bar shows the drag, snaps back after ~0.5s, playback position
            // never actually changes. Every plausible cause I could confirm
            // by reading (bridge wiring, native seekTo/seekWithinCurrentTrack,
            // the dragRatio-holds-until-convergence logic) checked out fine
            // on paper, so this logs the one thing static reading can't
            // settle: whether AudioEngine.seekTo actually gets called, what
            // it resolves/throws, and whether the polled position (pct) ever
            // moves afterward. Safe to strip once diagnosed.
            console.log('[SEEK-DEBUG] committing seek', { targetRatio, targetSeconds: targetRatio * duration, duration });
            seekChainRef.current = seekChainRef.current.then(async () => {
                if (latestSeekRatioRef.current !== targetRatio) {
                    console.log('[SEEK-DEBUG] superseded before its turn, skipped', { targetRatio });
                    return;
                }
                try {
                    await AudioEngine.seekTo(targetRatio * duration);
                    console.log('[SEEK-DEBUG] seekTo resolved', { targetRatio });
                } catch (e) {
                    console.log('[SEEK-DEBUG] seekTo THREW', { targetRatio, error: String(e) });
                }
            });
        } else {
            console.log('[SEEK-DEBUG] commit skipped: no duration known yet');
            // No known duration to seek within — nothing was actually
            // asked of native, so there's nothing to wait on converging.
            clearDragTimer.current = setTimeout(() => setDragRatio(null), 300);
        }
    };

    // The whole screen now has its own active vertical swipe-to-close gesture
    // (via React Navigation), which was winning gesture arbitration against
    // the progress bar's old plain-Responder touch handling for any drag with
    // even a slight vertical component — "only tap works now, not swipe."
    // Rebuilt on gesture-handler with activeOffsetX so a horizontal drag on
    // the bar correctly claims priority over the screen's vertical gesture.
    const onScrubRef = useRef(onScrub);
    useEffect(() => { onScrubRef.current = onScrub; });

    // These MUST stay referentially stable across renders (recreating them
    // mid-gesture is what caused the earlier RNGH crash), so they delegate
    // through onScrubRef instead of closing over onScrub directly — closing
    // directly would freeze `progress` at whatever it was on the very first
    // render (duration likely still 0), which is why dragging updated the
    // visual position but never actually called seekTo.
    // Set the moment the PAN handler actually reports movement (which only
    // happens once real dragging has crossed activeOffsetX below) — lets
    // the tap handler's onTapStateChange know a real drag is already
    // underway, so it can bail out below instead of double-committing.
    const realDragMovedRef = useRef(false);

    const onProgressGestureEvent = useRef((e) => {
        realDragMovedRef.current = true;
        onScrubRef.current(e.nativeEvent.absoluteX, false);
    }).current;

    const onProgressStateChange = useRef((e) => {
        const { state, absoluteX } = e.nativeEvent;
        if (state === GHState.BEGAN) {
            holdDismissRef.current(true);
            measureProgress();
            committedRef.current = false;
            realDragMovedRef.current = false;
            gestureTrackIdRef.current = nowTrackIdRef.current;
            onScrubRef.current(absoluteX, false);
            clearTimeout(stuckSafetyTimer.current);
            stuckSafetyTimer.current = setTimeout(() => {
                onScrubRef.current(lastTouchX.current, true);
            }, 500);
        }
        if (state === GHState.END || state === GHState.CANCELLED || state === GHState.FAILED) {
            onScrubRef.current(absoluteX, true);
            holdDismissRef.current(false);
        }
    }).current;

    // A plain stationary tap has been the one case that's stayed broken
    // across several attempts at handling it through PanGestureHandler's own
    // BEGAN/END states — this hands taps to a purpose-built TapGestureHandler
    // running SIMULTANEOUSLY with the pan handler instead, which is the
    // standard gesture-handler pattern for "tap or drag on the same view."
    // It fires reliably on ACTIVE for a genuine tap regardless of whatever
    // the pan handler's own state transitions do for a zero-movement touch,
    // and simply fails (no-op here) for anything that turns into a real
    // drag, since the pan handler already covers that case above.
    //
    // Real bug found here: "fails for anything that turns into a real drag"
    // was the intent, but TapGestureHandler has no maxDist/maxDeltaX
    // configured, so its default recognition window was loose enough to
    // still fire ACTIVE for the first moment of a genuine drag — before
    // enough movement had accrued to fail it out. That meant a drag could
    // trigger an early, premature commit here (seeking to wherever the
    // finger was in that first instant) via this handler, and then the
    // pan handler's OWN later END commit got silently dropped by
    // committedRef's already-committed guard — audible as the position
    // jumping to the wrong place first, then not responding to the actual
    // release ("double-plays when dragging"). Checking realDragMovedRef
    // here — set the moment the pan handler reports any real movement —
    // closes that window: once a real drag has started, this handler is
    // never allowed to commit, full stop, regardless of its own state.
    const panRef = useRef(null);
    const tapRef = useRef(null);
    const onTapStateChange = useRef((e) => {
        if (e.nativeEvent.state === GHState.BEGAN) holdDismissRef.current(true);
        if (e.nativeEvent.state === GHState.END || e.nativeEvent.state === GHState.CANCELLED || e.nativeEvent.state === GHState.FAILED) holdDismissRef.current(false);
        if (e.nativeEvent.state === GHState.ACTIVE && !realDragMovedRef.current) {
            measureProgress();
            // A tap is its own complete gesture: it must start from a
            // clean slate (see nowTrackIdRef's comment) instead of
            // inheriting whatever the last drag left behind.
            committedRef.current = false;
            gestureTrackIdRef.current = nowTrackIdRef.current;
            onScrubRef.current(e.nativeEvent.absoluteX, true);
        }
    }).current;

    useEffect(() => {
        if (playlist && (!currentPlaylist || currentPlaylist.path !== playlist.path)) {
            loadPlaylist(playlist);
        }
    }, []);

    const displayTitle = currentTrack?.ourTitle ?? currentTrack?.title ?? '—';
    const displayArtist = formatArtists(currentTrack?.ourArtist ?? currentTrack?.artist ?? '', artistSeparator, artistDisplayJoin);
    // No per-song embedded-artwork (ID3/FLAC picture tag) extraction exists
    // anywhere in this codebase yet — currentTrack.artwork is never actually
    // populated, so "song covers" were always silently falling back to the
    // note glyph. This falls back to the PLAYLIST's cover image instead,
    // which is real data we already have. True per-file embedded artwork
    // would need a native module or a metadata-parsing library — a separate,
    // bigger feature if you want it.
    const artwork = playerArtUri(currentTrack?.artwork);
    const pct = justSwitched ? (switchProg.duration > 0 ? Math.min(1, switchProg.position / switchProg.duration) : 0) : (progress.duration > 0 ? progress.position / progress.duration : 0);

    // Lyrics: 'off' never even attempts a .lrc lookup (no wasted file I/O
    // for anyone who doesn't use this). 'manual' and 'auto' both look up
    // lyrics for every new track; the only difference is whether
    // `showingLyrics` starts true or false for a track that has them —
    // 'auto' defaults to showing them, 'manual' still defaults to the
    // cover but makes the toggle available. Either way this resets on
    // every track change, not just once — a manual toggle from a previous
    // song shouldn't carry over to the next one.
    const initialLyricsPeek = peekLyrics(currentTrack?.id);
    // Both are tagged with the song they belong to. Right after a song change (the title switches at the
    // crossfade midpoint) the old song's lyrics, or its "lyrics showing" state, were still what rendered
    // until the new lookup finished; now anything that is not for the current song counts as not there.
    const [lyricsRaw, setLyricsRaw] = useState(() => ({ id: currentTrack?.id, data: initialLyricsPeek !== undefined ? initialLyricsPeek : null }));
    const [showingRaw, setShowingRaw] = useState(() => ({ id: currentTrack?.id, on: autoShowLyrics && !!initialLyricsPeek }));
    const nowId = currentTrack?.id;
    const nowIdRef = useRef(nowId);
    nowIdRef.current = nowId;
    const lyricsBase = lyricsRaw.id === nowId ? lyricsRaw.data : (peekLyrics(nowId) ?? null);
    // With a Blank Line Gap set, the lyrics start on a blank line (when the intro is at least a gap long) and end on one
    // (after the last line), the same kind of empty row a long wordless stretch gets, so the first and last lines sit one row
    // away from where the active line rests instead of right on it. The end one starts when the last line has had
    // a full gap's worth of time (or at the file's own trailing empty timestamp, if it has one). Off = untouched.
    const lyricsData = useMemo(() => {
        if (!lyricsBase || !lyricsBase.length || !(lyricsGapSec > 0)) return lyricsBase;
        const firstText = lyricsBase.findIndex(l => l.text);
        if (firstText < 0) return lyricsBase;
        let lastText = lyricsBase.length - 1;
        while (lastText > firstText && !lyricsBase[lastText].text) lastText--;
        const body = lyricsBase.slice(firstText, lastText + 1);
        const trailing = lyricsBase[lastText + 1];
        // The end row starts a full gap after the last line (a file's own trailing empty timestamp counts only if it is later).
        const endTime = Math.max(trailing ? trailing.time : 0, lyricsBase[lastText].time + lyricsGapSec);
        // The last entry only exists so the end row counts as a gap row (a gap row needs an entry after it); it is
        // never reached, so the view stays on the end row until the song ends.
        // The start follows the same rule as any other gap: the stretch from 0 s to the first line must be at least the
        // gap long to get its own blank row (then the song opens on that row, first line one row below). A shorter
        // intro has no blank row and the first line sits where the active line sits.
        const startBlank = body[0].time >= lyricsGapSec ? [{ time: -1000, text: '' }] : [];
        return [
            ...startBlank,
            ...body,
            { time: endTime, text: '' },
            { time: 1e9, text: '' },
        ];
    }, [lyricsBase, lyricsGapSec]);
    const showingLyrics = showingRaw.id === nowId ? showingRaw.on : (autoShowLyrics && !!peekLyrics(nowId));
    // When this song became the current one. A view change that comes right after it (a song with lyrics follows one
    // without) is part of the song change, not a button press, and is shown at once: see the view effect below.
    const trackChangeIdRef = useRef(nowId);
    const trackChangedAtRef = useRef(0);
    if (trackChangeIdRef.current !== nowId) { trackChangeIdRef.current = nowId; trackChangedAtRef.current = Date.now(); }
    // The cover's visualizer overlay (which also dims the cover) stays mounted until the cover has finished fading
    // out. It used to go the moment the lyrics came on, so the fading cover showed at full brightness.
    const [vizHold, setVizHold] = useState(showingLyrics);
    useEffect(() => {
        if (!showingLyrics) { setVizHold(false); return undefined; }
        const t = setTimeout(() => setVizHold(true), 420);
        return () => clearTimeout(t);
    }, [showingLyrics]);
    const setLyricsData = useCallback((data) => setLyricsRaw({ id: nowIdRef.current, data }), []);
    const setShowingLyrics = useCallback((on) => setShowingRaw({ id: nowIdRef.current, on }), []);
    // Reading the next songs' lyrics ahead of time (the .lrc files are tiny): a skip or a crossfade to a song with
    // lyrics then finds them already read, so the lyrics are there the moment the title switches instead of the
    // cover showing for a split second first.
    useEffect(() => {
        if (!currentTrack?.id) return undefined;
        let cancelled = false;
        (async () => {
            try {
                const [q, idx] = await Promise.all([AudioEngine.getQueue(), AudioEngine.getCurrentTrack()]);
                if (cancelled || !Array.isArray(q) || typeof idx !== 'number') return;
                for (const t of q.slice(idx + 1, idx + 4)) {
                    if (cancelled) return;
                    if (t?.id && peekLyrics(t.id) === undefined) await getLyrics(t);
                }
            } catch { }
        })();
        return () => { cancelled = true; };
    }, [currentTrack?.id]);
    useEffect(() => {
        if (!currentTrack?.id || lyricsMode === 'off') {
            setLyricsData(null);
            setShowingLyrics(false);
            return;
        }
        // Already resolved this song's lyrics earlier this session (common
        // — reopening the Player, or a background prefetch already ran) —
        // apply immediately instead of always going through the promise
        // below, which was the actual source of the "cover shows for a
        // split second before lyrics" report: even a cache-hit promise
        // still resolves a tick after first paint, so the cover-first frame
        // rendered every time regardless of how fast the real lookup was.
        const cached = peekLyrics(currentTrack.id);
        if (cached !== undefined) {
            setLyricsData(cached);
            setShowingLyrics(autoShowLyrics && !!cached);
            return;
        }
        let cancelled = false;
        let retryTimer = null;
        const startedAt = Date.now();
        // A read that fails (the disk busy with a library scan or cover work, a file still being
        // written) used to leave this song without lyrics until the next song. It is now tried
        // again every 1.5 s, up to 20 times. A slow lookup is written to the Debug Log.
        const attempt = (n) => {
            getLyrics(currentTrack).then(data => {
                if (cancelled) return;
                if (data === undefined && n < 20) {
                    console.log(`[LYRICS] reading the lyrics file failed (try ${n + 1}), trying again`);
                    retryTimer = setTimeout(() => attempt(n + 1), 1500);
                    return;
                }
                const took = Date.now() - startedAt;
                if (took > 1000) console.log(`[LYRICS] lyrics lookup took ${took} ms (${n} retries)`);
                setLyricsData(data || null);
                setShowingLyrics(autoShowLyrics && !!data);
            });
        };
        attempt(0);
        return () => { cancelled = true; if (retryTimer) clearTimeout(retryTimer); };
    }, [currentTrack?.id, autoShowLyrics, lyricsMode]);

    // Only polls directly when useProgress doesn't yet have real data to
    // offer — either genuinely paused (position isn't moving on its own, so
    // one read per pause/track-change is enough), or playing but
    // useProgress hasn't ticked yet since mount/track-change (its own poll
    // interval hasn't landed once yet). That second case is why lyrics
    // previously stayed on the wrong line until the NEXT natural line
    // change caught it up — activeLine was gated on progress.duration but
    // nothing seeded a real value in the meantime. Deliberately NOT
    // continuous while progress.duration is already known and playing:
    // getProgress() and setVolume() share the same JS-bridge queue, so a
    // second poller running throughout playback could delay fadeVol's
    // ~25/sec setVolume steps — audible as jitter, and very likely the
    // actual cause of the newly-reported "ramping is glitchy/jumpy going
    // into a song" after this was first added as an always-on interval.
    // Real gap found here (opening straight into lyrics from a cold-launch
    // restore, paused, before ever pressing Play): this always started at
    // position:0/duration:0 regardless of what was already known, so even
    // though activeLine's own gate (below) is correct, there was still a
    // real — if brief — window right as showingLyrics flips true where
    // activeLine had nothing to work with yet, landing on the activeLine<0
    // branch (scrolls to the top / whatever it last was) before the first
    // getProgress() round trip below actually resolves a moment later and
    // the real position takes over. useProgress's own poll (progress,
    // above) may well already have a real value by the time lyrics finish
    // resolving — seeding from that instead of a hardcoded zero closes the
    // gap for that common case instead of always eating one avoidable
    // async round trip's worth of wrong-content flash.
    const [lyricsProgress, setLyricsProgress] = useState(() => (progress.duration > 0 ? progress : { position: 0, duration: 0 }));
    const progressKnown = progress.duration > 0;
    useEffect(() => {
        if (!showingLyrics || (isPlaying && progressKnown)) return;
        // Was a single one-shot getProgress() call, not a repeating poll —
        // fine as long as (isPlaying && progressKnown) flips true shortly
        // after (useProgress's own poll catches up) and this effect stops
        // being the source of truth. But if progressKnown never becomes
        // true for a given track (useProgress's poll firing but duration
        // never validated — a metadata thing worth its own look, but not
        // reproducible from here), this fallback was never called again
        // either, since none of its dependencies change while stuck in
        // that state — lyricsProgress just froze at whatever position it
        // caught on that first, one-time fetch. That's the "sometimes
        // doesn't follow the song, stays at start" report: whatever
        // position happened to be current at that single fetch (often
        // near the very start) is what the lyrics view was stuck showing
        // forever. Polling here too, same as useProgress's own interval,
        // means lyrics keep tracking regardless of whether the primary
        // progress source ever recovers.
        let cancelled = false;
        const tick = () => {
            AudioEngine.getProgress().then(p => { if (!cancelled) setLyricsProgress(p); }).catch(() => { });
        };
        tick();
        const id = setInterval(tick, 500);
        return () => { cancelled = true; clearInterval(id); };
    }, [showingLyrics, isPlaying, progressKnown, currentTrack?.id]);

    // Prefer useProgress's own live value once it's actually populated;
    // otherwise (paused, or playing but not populated yet) fall back to the
    // one-shot read above.
    // The fallback reading comes straight from native, so it can still describe the song that was
    // playing before (right after a crossfade changes songs, native keeps answering for the old one
    // for a moment): it is matched to the song shown like `progress` is. Unmatched, the new song's
    // lyrics were placed on the old song's position (near the end), then slid back to the top.
    const lyricsProgressMatched = useMemo(
        () => matchProgress(lyricsProgress, currentTrack?._qid, currentTrack?.duration || knownDur, currentTrack?.id),
        [lyricsProgress, currentTrack?._qid, currentTrack?.duration, currentTrack?.id]
    );
    const effectiveLyricsProgress = (isPlaying && progressKnown) ? progress : lyricsProgressMatched;

    // Same "is progress real yet" gate used elsewhere in this file (pct,
    // animPct, etc.) — position:0/duration:0 before the first real poll
    // lands. Without this, activeLine briefly computed against position 0
    // regardless of where the song actually is, so the lyrics view jumped
    // to the very first line and then jumped again once the real position
    // arrived a moment later — the reported "not synced when the player is
    // just opened".
    const baseActiveLine = (lyricsData && effectiveLyricsProgress.duration > 0) ? activeLyricIndex(lyricsData, effectiveLyricsProgress.position + lyricsOffsetSec) : -1;

    // The position only arrives every 500 ms, so a line used to switch up to half a
    // second late (and only on a poll). While the lyrics are showing and the song is
    // playing, the position is carried forward with the clock between polls and the
    // line is picked from that, so lines change on time, to the millisecond of the file.
    //
    // The carried-forward position must never run on stale data. It used to keep counting from the
    // last reading even while paused, so pressing Play after a pause made the lyrics jump ahead by
    // the whole pause (a second, or a minute) until the next reading arrived. Now: the sample is
    // restarted whenever play/pause flips, it only carries forward after a reading that actually
    // moved since playing began, and it never carries more than LYRIC_CARRY_MAX_SEC past a reading.
    const lyricSample = useRef({ pos: 0, at: 0, moving: false });
    const lyricPlayingRef = useRef(isPlaying);
    useEffect(() => {
        const prev = lyricSample.current;
        const flipped = lyricPlayingRef.current !== isPlaying;
        lyricPlayingRef.current = isPlaying;
        const pos = effectiveLyricsProgress.position;
        const moved = !flipped && isPlaying && Math.abs(pos - prev.pos) > 0.001;
        // Same position as before while playing = no new information: keep the older, honest stamp.
        if (!flipped && isPlaying && !moved && prev.at > 0) return;
        lyricSample.current = { pos, at: Date.now(), moving: moved || (isPlaying && prev.moving && !flipped) };
    }, [effectiveLyricsProgress.position, effectiveLyricsProgress.duration, currentTrack?.id, isPlaying]);
    const [liveLine, setLiveLine] = useState(null);
    const lyricsLive = !!(showingLyrics && isPlaying && lyricsData && effectiveLyricsProgress.duration > 0);
    useEffect(() => {
        if (!lyricsLive) { setLiveLine(null); return undefined; }
        const rate = playbackRate || 1;
        const tick = () => {
            const smp = lyricSample.current;
            const carry = smp.moving ? Math.min(Math.max(0, (Date.now() - smp.at) / 1000), LYRIC_CARRY_MAX_SEC) : 0;
            const pos = smp.pos + carry * rate;
            const idx = activeLyricIndex(lyricsData, pos + lyricsOffsetSec);
            setLiveLine(prev => ((prev && prev.d === lyricsData && prev.i === idx) ? prev : { d: lyricsData, i: idx }));
        };
        tick();
        const id = setInterval(tick, 60);
        return () => clearInterval(id);
    }, [lyricsLive, lyricsData, lyricsOffsetSec, playbackRate]);
    // The live line only counts for the lyrics it was worked out on: right after a song change it
    // still held the old song's line number for a moment, which was then used on the new lyrics.
    const rawActiveLine = (lyricsLive && liveLine && liveLine.d === lyricsData) ? liveLine.i : baseActiveLine;
    // A timestamp with no words (an instrumental stretch) is not shown at all and lights nothing up: while the
    // song is in one, no line is active (-3) and the lyrics sit halfway between the line before and the line after.
    // With a Blank Line Gap set, a wordless stretch at least that long keeps its own empty line of space (and can be the
    // active line, so the lyrics rest on it); shorter ones stay invisible as before.
    const isGapLine = (i) => lyricsGapSec > 0 && !!lyricsData && !!lyricsData[i] && !lyricsData[i].text
        && !!lyricsData[i + 1] && (lyricsData[i + 1].time - lyricsData[i].time) >= lyricsGapSec;
    const activeLine = (rawActiveLine >= 0 && lyricsData && !lyricsData[rawActiveLine]?.text && !isGapLine(rawActiveLine)) ? -3 : rawActiveLine;

    // Seeded from the same initial guess as showingLyrics above (not always
    // 0/cover) so a cache-hit mount goes straight to lyrics without playing
    // the 280ms crossfade on first paint — that fade is for a real
    // cover<->lyrics transition, not something that should visibly happen
    // every time the Player screen opens.
    // DJ disc view. Lives alongside the lyrics view: the button under the
    // cover cycles cover -> lyrics (if the song has them) -> disc (if the
    // setting is on) -> cover. At most one of the two is showing.
    // Starts already on the disc when Auto Disc is on, so reopening the Player
    // does not show the cover for a moment and then fade over to the disc.
    const [showingDisc, setShowingDisc] = useState(() => !!(autoShowDisc && !autoShowLyrics));
    const discFade = useRef(new Animated.Value(showingDisc ? 1 : 0)).current;
    // True from the moment the disc is chosen until it has completely faded
    // out again: the disc keeps spinning for that whole time, so switching
    // away looks like it is still playing in the background.
    const [discActive, setDiscActive] = useState(() => !!(autoShowDisc && !autoShowLyrics));
    useEffect(() => { if (showingDisc) setDiscActive(true); }, [showingDisc]);
    // Auto Disc: every new song opens on the disc (like Auto-show lyrics does
    // for lyrics; the two settings can never both be on). Otherwise each new
    // song goes back to the cover unless the lyrics view claims it.
    // A new song opens on lyrics if Auto Show Lyrics is on and the song has
    // them, else on the disc if Auto Show Disc is on, else the cover (also
    // the fallback when all three are off). The lyrics part is decided in the
    // lyrics effect above once the lyrics are known.
    useEffect(() => {
        if (autoShowDisc && !(autoShowLyrics && peekLyrics(currentTrack?.id))) setShowingDisc(true);
        else setShowingDisc(false);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentTrack?.id, autoShowDisc, autoShowLyrics]);
    // The Player's swipe-down-to-close works from anywhere above the controls,
    // which would close it whenever the disc is dragged downward. It is turned
    // off only while a finger is on the disc itself (see DJDisc's onTouching).
    // True while a play/pause fade is running. The disc ignores fingers meanwhile (scratching in the
    // middle of a fade left the song's volume half-ramped), and the play button ignores presses
    // while the disc is being scratched.
    const [fadeBusy, setFadeBusy] = useState(false);
    const fadeBusyTimer = useRef(null);
    useEffect(() => () => { if (fadeBusyTimer.current) clearTimeout(fadeBusyTimer.current); }, []);
    const [discHeld, setDiscHeld] = useState(false);
    const discHeldRef = useRef(false);
    const discHeldTimer = useRef(null);
    const setDiscTouching = useCallback((touching) => {
        discHeldRef.current = !!touching;
        // Straight to the navigator, NOT through a state change and an effect: that route
        // re-rendered this whole screen first, and the swipe-down gesture could take the
        // touch from the disc before it was switched off ("touch taken over", 10-90 ms in).
        // Nothing is switched off here any more: the disc follows the finger with a native gesture
        // handler (see DJDisc), which the swipe-down-to-close cannot take a touch from. Switching the
        // navigator at the moment of the touch re-rendered it right when the scratch had to start.
        // discHeld only steers the progress bar. Setting it re-renders this whole screen, and doing that at the
        // moment of the lift landed in the middle of the release ease (the 20 ms timer that drives the sound's
        // speed and the disc was starved: a small stutter you could hear and see). It is applied a little
        // later, as a low-priority update, instead.
        if (discHeldTimer.current) clearTimeout(discHeldTimer.current);
        discHeldTimer.current = setTimeout(() => {
            discHeldTimer.current = null;
            startTransition(() => setDiscHeld(discHeldRef.current));
        }, touching ? 150 : 500);
    }, [navigation]);
    useEffect(() => () => { if (discHeldTimer.current) clearTimeout(discHeldTimer.current); }, []);
    useEffect(() => () => navigation.setOptions({ gestureEnabled: true }), [navigation]);
    // While the queue sheet is open, the Player's own swipe-down-to-close must be off:
    // dragging a queue row down (or up and then down) started it, and the whole Player
    // followed the finger ("the page moves"). The sheet closes from its own handle.
    // Swipe-down-to-close is off while the queue sheet is open. While a finger is on the disc
    // it is switched off too, but that is done directly in setDiscTouching (fast path above).
    const showQueueRef = useRef(false);
    showQueueRef.current = showQueue;
    useEffect(() => { navigation.setOptions({ gestureEnabled: !showQueue }); }, [navigation, showQueue]);
    // Swipe-down-to-close is also off while a finger is on the progress bar or on any button (a scrub or a press with
    // a little downward drift used to close the Player). Released as soon as the finger lifts; a backstop timer lets
    // go anyway if a lift is ever missed, so the gesture can never stay off.
    const dismissHoldTimer = useRef(null);
    const holdDismiss = useCallback((on) => {
        if (dismissHoldTimer.current) { clearTimeout(dismissHoldTimer.current); dismissHoldTimer.current = null; }
        if (on) dismissHoldTimer.current = setTimeout(() => { dismissHoldTimer.current = null; navigation.setOptions({ gestureEnabled: !showQueueRef.current }); }, 20000);
        navigation.setOptions({ gestureEnabled: on ? false : !showQueueRef.current });
    }, [navigation]);
    useEffect(() => () => { if (dismissHoldTimer.current) clearTimeout(dismissHoldTimer.current); }, []);
    const holdDismissRef = useRef(holdDismiss);
    holdDismissRef.current = holdDismiss;
    const HOLD = { onPressIn: () => holdDismissRef.current(true), onPressOut: () => holdDismissRef.current(false) };
    // Leaving the disc view always lets go of a finger-on-disc state and turns the gesture back on.
    useEffect(() => { if (!showingDisc && discHeldRef.current) { discHeldRef.current = false; setDiscHeld(false); navigation.setOptions({ gestureEnabled: !showQueueRef.current }); } }, [showingDisc, navigation]);
    // The swipe-down-to-close gesture is only switched off AFTER a finger lands on
    // the disc, and that takes a moment to reach the native side, so it is sent
    // straight to the navigator (see setDiscTouching) to keep that moment as short as
    // possible. Swipe-down-to-close works from anywhere above the controls.
    const discAreaRef = useRef(null);
    const discTopRef = useRef(0);
    const controlsYRef = useRef(0);
    const discZoneOn = useRef(false);
    const applyDismissZone = useCallback(() => {
        const d = controlsYRef.current;   // swipe-down works from anywhere above the controls (the disc box excepted, see DJDisc)
        if (d > 0) navigation.setOptions({ gestureResponseDistance: d });
    }, [navigation]);
    const measureDiscArea = useCallback(() => {
        if (discAreaRef.current) discAreaRef.current.measureInWindow((x, y) => { if (y > 60 && y < 500) { discTopRef.current = y; applyDismissZone(); } });
    }, [applyDismissZone]);
    // The controls are measured while the Player is still sliding up, so the swipe-down zone could be
    // set from a position the screen was not going to stay at (and was only corrected by touching
    // something). Measured again when the open animation has finished, and whenever the screen is focused.
    useEffect(() => {
        const remeasure = () => {
            controlsRef.current?.measureInWindow((x, y) => { if (y > 0) { controlsYRef.current = y; applyDismissZone(); } });
            measureDiscArea();
        };
        const u1 = navigation.addListener('transitionEnd', (e) => { if (!e?.data?.closing) remeasure(); });
        const u2 = navigation.addListener('focus', () => { setTimeout(remeasure, 50); });
        const t = setTimeout(remeasure, 600);
        return () => { u1(); u2(); clearTimeout(t); };
    }, [navigation, applyDismissZone, measureDiscArea]);
    useEffect(() => {
        discZoneOn.current = !!(showingDisc && djDisc);
        measureDiscArea();
        applyDismissZone();
    }, [showingDisc, djDisc, measureDiscArea, applyDismissZone]);
    useEffect(() => { if (showingLyrics && showingDisc) setShowingDisc(false); }, [showingLyrics, showingDisc]);
    const hasLyricsView = !!lyricsData;
    // The disc only exists when the DJ Disc setting is on.
    useEffect(() => { if (!djDisc) setShowingDisc(false); }, [djDisc]);
    const cycleView = () => {
        // cover -> lyrics -> disc -> cover, skipping what is unavailable.
        if (showingLyrics) { setShowingLyrics(false); if (djDisc) setShowingDisc(true); return; }
        if (showingDisc) { setShowingDisc(false); return; }
        if (hasLyricsView) { setShowingLyrics(true); return; }
        if (djDisc) setShowingDisc(true);
    };
    const nextViewLabel = showingLyrics ? (djDisc ? 'Show disc' : 'Show cover')
        : showingDisc ? 'Show cover'
        : hasLyricsView ? 'Show lyrics' : 'Show disc';
    // Protected zones for scratching: start of the song, and the end where a
    // crossfade or fade-out runs, plus a safety margin.
    // The start of a song that came in by crossfade overlaps the end of the
    // one before it for the crossfade's length, so the disc keeps out of that too.
    const scratchStartGuard = Math.max(crossfadeEnabled ? Math.max(crossfadeDuration || 0, crossfadeDurationEndOfTrack || 0) : 0, 2) + 1;
    const scratchEndGuard = Math.max(crossfadeEnabled ? Math.max(crossfadeDuration || 0, crossfadeDurationEndOfTrack || 0) : 0, 2) + 8;
    // Cover / lyrics / disc share one slot. Each has ONE opacity (no nested
    // fades, no scaling: stacked fades on the shadowed cover were what made
    // its outline flash). The outgoing view fades out first and the incoming
    // one starts a moment later, so the two never sit on screen half
    // transparent on top of each other (the old cover-peeking-through).
    const lyricsFade = useRef(new Animated.Value(showingLyrics ? 1 : 0)).current; // lyrics layer
    const coverFade = useRef(new Animated.Value(showingLyrics || showingDisc ? 0 : 1)).current; // cover layer
    // The lyrics layer's opacity is lyricsFade x lyricsShown, both ALWAYS attached to the view.
    // It used to be `lyricsPlaced ? lyricsFade : 0`, which attached and detached lyricsFade every
    // time the lyrics view was left or opened. A detached native-driven value keeps running (or
    // stops) out of sight and is out of step when it is attached again, so pressing the view
    // button repeatedly could bring the lyrics in at full strength on top of the fading cover.
    // lyricsShown is 0 only while the lyrics view is open but not yet put on its line.
    const lyricsShown = useRef(new Animated.Value(0)).current;
    const lyricsOpacity = useRef(Animated.multiply(lyricsFade, lyricsShown)).current;
    const viewMounted = useRef(false);
    const viewAnimRef = useRef(null);
    const viewSettleTimer = useRef(null);
    useEffect(() => {
        if (!viewMounted.current) { viewMounted.current = true; return; }
        const go = (v, on) => on
            ? Animated.sequence([Animated.delay(170), Animated.timing(v, { toValue: 1, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true })])
            : Animated.timing(v, { toValue: 0, duration: 190, easing: Easing.in(Easing.quad), useNativeDriver: true });
        const coverOn = !showingLyrics && !showingDisc;
        // The lyrics coming on right after a song change: the cover shown for them is the NEW song's, which would flash
        // up for the fade. It is hidden at once and the lyrics come in without the usual wait.
        const withSongChange = showingLyrics && !showingDisc && Date.now() - trackChangedAtRef.current < 600;
        // The previous change-over must be stopped first. Its delayed "fade in" step could still
        // be waiting (170 ms) when a newer change-over started (a song with lyrics flips the view
        // twice in a row), and then fired afterwards, overwriting the newer one: the disc ended up
        // invisible while it was the selected view.
        if (viewAnimRef.current) viewAnimRef.current.stop();
        // stopTogether:false is the fix for "disc invisible but still scratchable" and "cover
        // showing through the lyrics". Animated.parallel stops EVERY animation in the group as
        // soon as one of them is stopped, and one always was: the lyrics layer's opacity is bound
        // to lyricsFade only while lyricsPlaced is true, and React Native stops a native-driven
        // value the moment it loses its view binding. Leaving the lyrics view flips lyricsPlaced
        // to false, which stopped lyricsFade, which (with the default) stopped the disc's delayed
        // fade-in and the cover's fade as well, leaving them stuck at whatever they had reached.
        if (withSongChange) coverFade.setValue(0);
        const lyricsIn = withSongChange
            ? Animated.timing(lyricsFade, { toValue: 1, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true })
            : go(lyricsFade, showingLyrics);
        const anim = Animated.parallel([withSongChange ? Animated.timing(coverFade, { toValue: 0, duration: 1, useNativeDriver: true }) : go(coverFade, coverOn), lyricsIn, go(discFade, showingDisc)], { stopTogether: false });
        viewAnimRef.current = anim;
        anim.start(({ finished }) => {
            if (viewAnimRef.current === anim) viewAnimRef.current = null;
            if (finished && !showingDisc) setDiscActive(false);
        });
        // Safety net: whatever happened to the animations above (stopped by a detach, replaced by
        // a quick second press, dropped while the app was busy), once they should have finished
        // every layer is put at exactly the value its view calls for. A layer that already
        // reached it does not visibly change.
        if (viewSettleTimer.current) clearTimeout(viewSettleTimer.current);
        viewSettleTimer.current = setTimeout(() => {
            viewSettleTimer.current = null;
            coverFade.setValue(coverOn ? 1 : 0);
            lyricsFade.setValue(showingLyrics ? 1 : 0);
            discFade.setValue(showingDisc ? 1 : 0);
            if (!showingDisc) setDiscActive(false);
        }, 700);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [showingLyrics, showingDisc]);
    useEffect(() => () => { if (viewSettleTimer.current) clearTimeout(viewSettleTimer.current); }, []);

    const lyricsScrollRef = useRef(null);
    // Drives the per-line opacity fade (Spotify-style — replaces the old
    // box-edge gradient overlay entirely, see the lyrics map() below).
    const lyricsScrollY = useRef(new Animated.Value(0)).current;
    const lyricsRowYRef = useRef(new Map());
    const lyricsRowHRef = useRef(new Map());   // each row's height (a long line wraps to 2 or 3 lines)
    // For a line that wraps onto several rows of text: the text of each visual row, from
    // onTextLayout. Each visual row then fades on its own at the top and bottom edge, so a long
    // line fades smoothly instead of as one flat block.
    const lyricsLinesRef = useRef(new Map());
    const [, setLyricsLinesVersion] = useState(0);
    // Every new lyric set (a different song's lines) gets a new key, so its rows
    // remount and report their real positions through onLayout.
    const lyricsSetRef = useRef({ data: undefined, n: 0 });
    if (lyricsSetRef.current.data !== lyricsData) {
        lyricsSetRef.current = { data: lyricsData, n: lyricsSetRef.current.n + 1 };
        // The previous song's positions must not be readable for the new lines: the remount
        // below makes every row report a fresh one, and until then "not measured" is correct.
        lyricsRowYRef.current.clear();
        lyricsRowHRef.current.clear();
        lyricsLinesRef.current.clear();
    }
    const lyricsSetKey = lyricsSetRef.current.n;
    // Every line's opacity is worked out from lyricsScrollY, the list's scroll offset, which is
    // only ever updated by scroll events. A new set of lines (a new song, or lyrics appearing where
    // there were none, which builds a fresh list) starts at offset 0 WITHOUT any scroll event, so
    // lyricsScrollY kept the previous song's offset (say 1500): every line then counted as far
    // outside the box and was fully faded out. The lyrics stayed invisible until the list happened
    // to scroll, which a first line does not do (it sits where the list already is): "lyrics don't
    // show up until the second line", sometimes for 30 s. The value is now put back to 0 together
    // with the list whenever the set of lines changes.
    useEffect(() => {
        lyricsScrollY.setValue(0);
        lyricsScrollRef.current?.scrollTo({ y: 0, animated: false });
    }, [lyricsSetKey]);
    // Bumped every time a row's real Y position lands via onLayout — the
    // scroll-to-line effect below depends on this so it re-runs once the
    // position it needs actually exists, instead of only reacting to
    // activeLine/showingLyrics changes. Without it: onLayout for a given
    // line can land a frame or two after lyrics are toggled on or a track
    // just started (React Native's onLayout is inherently async), the
    // effect finds nothing yet in the map for the current line, silently
    // gives up, and — since nothing else re-triggers it — the view just
    // sits wherever it was until activeLine naturally changes to a new
    // line and the effect runs again with the position now populated.
    // That's the reported "doesn't jump to the line until the next line
    // change" — not a timing/animation issue, a dropped retry.
    const [lyricsLayoutVersion, setLyricsLayoutVersion] = useState(0);
    // Every row reports its layout on its own; each report used to re-render this whole screen
    // (20+ times when a song's lyrics appeared, which also held up the first placing). The
    // reports of one moment are now folded into a single re-render.
    const layoutBumpPending = useRef(false);
    const bumpLyricsLayout = () => {
        if (layoutBumpPending.current) return;
        layoutBumpPending.current = true;
        requestAnimationFrame(() => { layoutBumpPending.current = false; setLyricsLayoutVersion(v => v + 1); });
    };
    const linesBumpPending = useRef(false);
    // Manual scroll support: dragging the lyrics view pauses auto-sync;
    // after `lyricsResyncSec` idle seconds (Settings → Lyrics), it resumes
    // and snaps back to the currently-playing line.
    const [lyricsManualScroll, setLyricsManualScroll] = useState(false);
    const lyricsResyncTimer = useRef(null);
    const armResyncTimer = () => {
        if (lyricsResyncTimer.current) clearTimeout(lyricsResyncTimer.current);
        lyricsResyncTimer.current = setTimeout(() => setLyricsManualScroll(false), lyricsResyncSec * 1000);
    };
    useEffect(() => () => { if (lyricsResyncTimer.current) clearTimeout(lyricsResyncTimer.current); }, []);
    // "Lyrics don't reset to the top on a new song" — lyricsRowYRef never
    // got cleared on a track change, so a new song's ScrollView could start
    // out using stale row-Y values left over from the *previous* song's
    // layout (same index, different line, different height) until its own
    // onLayout calls landed and overwrote them one by one. Also explicitly
    // snap the scroll position itself back to the top and drop manual-scroll
    // mode, so a song switch always starts from a clean, unscrolled view
    // instead of wherever the last song's lyrics happened to leave it.
    useEffect(() => {
        // The row map is NOT cleared here any more. Clearing it, then relying on
        // onLayout to refill it, failed whenever a new song's line kept the same
        // index and height: onLayout does not fire again for an unchanged row, so
        // its Y stayed undefined and the scroll effect returned without scrolling.
        // Each new set of lines now remounts (lyricsSetKey below), which always
        // reports a fresh Y, so the stale entries are overwritten.
        setLyricsLayoutVersion(v => v + 1);
        setLyricsManualScroll(false);
        // A track change (skip, crossfade landing, natural advance) is a
        // jump too, same as a manual seek — see lyricsJustJumpedRef's
        // declaration.
        lyricsJustJumpedRef.current = true;
        lyricsScrollRef.current?.scrollTo({ y: 0, animated: false });
        // A new song hides the lyrics again until they are on the right line, so the top
        // of the list never shows for a moment and then jumps.
        lyricsPlacedRef.current = false;
        lyricsWaitSince.current = Date.now();
        setLyricsPlaced(false);
    }, [currentTrack?.id]);
    // "Lyrics should already be at the place in the song before needing to
    // move when the music player is opened" — this effect's scrollTo was
    // ALWAYS animated, including the very first positioning right after
    // showingLyrics flips true, so opening the lyrics view visibly
    // scrolled from the top into place instead of just appearing already
    // correct. Tracks whether showingLyrics was already true last render;
    // only that specific "just opened" transition snaps instantly — a
    // genuine active-line advance while already looking at the view still
    // animates normally.
    const wasShowingLyricsRef = useRef(showingLyrics);
    // The lyrics stay invisible until the view has been put on the right line once. Right after the
    // Player opens the real position (and the row measurements) can arrive a few frames late, and the
    // list used to show its top for that moment and then snap down. A short timer shows it anyway if
    // that placing never happens (a song with no timed line yet, a position that never arrives).
    const [lyricsPlaced, setLyricsPlaced] = useState(false);
    const lyricsPlacedRef = useRef(false);
    const lyricsWaitSince = useRef(Date.now());
    const markLyricsPlaced = () => {
        if (!lyricsPlacedRef.current) {
            lyricsPlacedRef.current = true;
            setLyricsPlaced(true);
            const waited = Date.now() - lyricsWaitSince.current;
            if (waited > 700) console.log(`[LYRICS] put on its line after ${waited} ms`);
        }
    };
    useEffect(() => { lyricsShown.setValue(lyricsPlaced || !showingLyrics ? 1 : 0); }, [lyricsPlaced, showingLyrics, lyricsShown]);
    useEffect(() => {
        if (!showingLyrics || lyricsPlaced) return undefined;
        const id = setTimeout(() => { console.log('[LYRICS] shown without a measured position (timeout)'); markLyricsPlaced(); }, 450);
        return () => clearTimeout(id);
    }, [showingLyrics, lyricsPlaced]);
    useEffect(() => {
        if (!showingLyrics) {
            wasShowingLyricsRef.current = false;
            // Every time the lyrics view is opened again it starts hidden until placed.
            if (lyricsPlacedRef.current) { lyricsPlacedRef.current = false; setLyricsPlaced(false); }
            lyricsWaitSince.current = Date.now();
            return;
        }
        const justOpened = !wasShowingLyricsRef.current;
        // Real gap found here: this used to mark "opened" true on the very
        // first run regardless of activeLine. But activeLine starts at -1
        // (progress hasn't polled yet, duration still 0 — see its own
        // computation above) for whatever brief window that takes, so the
        // FIRST positioning this effect does is necessarily a guess (top of
        // the list, the activeLine<0 branch below). Once real progress
        // lands a moment later and activeLine becomes the actual current
        // line, wasShowingLyricsRef was already true — so THAT correction
        // (top → the real position) no longer counted as "just opened" and
        // animated instead of snapping, which is exactly "opening the
        // player visibly scrolls the lyrics into place" rather than
        // already being there. Only mark "opened" once there's a genuine
        // line to have opened on, so that first real correction still
        // counts as part of opening.
        // Either kind of jump (view just opened, or a seek/track-change
        // just happened) should snap instead of animate — only a natural
        // one-line-at-a-time advance while already sitting on the view
        // should animate. Only actually consumed (both this and
        // wasShowingLyricsRef below) once a scrollTo genuinely happens —
        // see the y===undefined bail-out below for why: the target row not
        // being measured yet is a second, separate way this could still
        // end up animating a correction that should have snapped.
        const skipAnimation = justOpened || lyricsJustJumpedRef.current;
        // Before the song reaches its first timed line (activeLine === -1,
        // e.g. a [00:00]-style intro gap, or seeking back to the very
        // start), this used to just no-op and leave the view wherever it
        // last was — "should automatically go to the start if the song
        // hasn't started the lyrics yet." Scroll to top for that case too,
        // not just skip it, and release manual-scroll so a deliberate
        // scroll-up-to-the-top by the user doesn't immediately get
        // overridden by the very next tick before the position has
        // actually caught up.
        if (activeLine === -3) {
            if (lyricsManualScroll) return;
            const arr = lyricsData || [];
            let prev = rawActiveLine - 1; while (prev >= 0 && !arr[prev]?.text) prev--;
            let next = rawActiveLine + 1; while (next < arr.length && !arr[next]?.text) next++;
            const hasPrev = prev >= 0, hasNext = next < arr.length;
            const yPrev = hasPrev ? lyricsRowYRef.current.get(prev) : undefined;
            const yNext = hasNext ? lyricsRowYRef.current.get(next) : undefined;
            if ((hasPrev && yPrev === undefined) || (hasNext && yNext === undefined)) return;   // wait for the rows to be measured
            let target;
            // Halfway between the BOTTOM of the line before and the TOP of the line after (the line before can be 2 or 3
            // lines tall). The 17 is half of a one-line row: the spot an active line's middle rests on.
            if (hasPrev && hasNext) target = (yPrev + (lyricsRowHRef.current.get(prev) ?? 34) + yNext) / 2 - 17;
            else if (hasPrev) target = yPrev;
            else if (hasNext) target = yNext;
            else return;
            lyricsScrollRef.current?.scrollTo({ y: Math.max(0, target - (width - 56) * 0.5), animated: !skipAnimation });
            if (effectiveLyricsProgress.duration > 0) {
                wasShowingLyricsRef.current = true;
                lyricsJustJumpedRef.current = false;
                markLyricsPlaced();
            }
            return;
        }
        if (activeLine < 0) {
            if (lyricsManualScroll) return;
            // Real gap in the fix above (the y===undefined guard's twin
            // case, missed on the first pass): activeLine is forced to -1
            // for TWO different reasons — genuinely before the song's
            // first timed line (duration>0, a real, stable state worth
            // consuming the flags for), or simply because
            // effectiveLyricsProgress.duration isn't known yet right after
            // opening (progress hasn't polled). That second case looked
            // identical to the first here, so the very first run — before
            // real position data ever arrived — was scrolling to 0 (fine,
            // that's where it already was) AND immediately marking
            // "opened" + clearing the jump flag. The NEXT run, once
            // duration/position actually loaded and activeLine resolved to
            // the real current line, then found both flags already
            // consumed and animated the correction — which is exactly
            // "starts at the top, then scrolls down by itself." Only
            // consuming the flags once duration>0 confirms this -1 is the
            // real, stable answer (not a placeholder) closes that gap.
            const isRealPosition = effectiveLyricsProgress.duration > 0;
            // Before the first line: sit exactly where the first line will sit once it is the
            // active one, so when it lights up nothing has to move. (Used to scroll to 0, which
            // is only the same spot when the first row happens to be near the top.) The first
            // row not being measured yet: wait for its layout rather than guess.
            const firstIdx = Math.max(0, (lyricsData || []).findIndex(l => l.text));   // an empty first timestamp has no row
            const firstY = lyricsRowYRef.current.get(firstIdx);
            if (firstY === undefined && lyricsData?.length) return;
            const preRollY = firstY === undefined ? 0 : Math.max(0, firstY - (width - 56) * 0.5);
            lyricsScrollRef.current?.scrollTo({ y: preRollY, animated: !skipAnimation });
            if (isRealPosition) {
                wasShowingLyricsRef.current = true;
                lyricsJustJumpedRef.current = false;
                markLyricsPlaced();
            }
            return;
        }
        if (lyricsManualScroll) return;
        const y = lyricsRowYRef.current.get(activeLine);
        // Real gap found here too: this used to bail out on an unmeasured
        // row WITHOUT the guard above — meaning by the time
        // lyricsLayoutVersion bumps (the row finally lays out) and this
        // effect re-runs, justOpened/lyricsJustJumpedRef had already been
        // consumed by THIS run even though it never actually positioned
        // anything. The real, only-successful positioning then landed on a
        // later run with skipAnimation already false — animating in
        // exactly the same way the activeLine<0 race above did. Returning
        // before consuming either flag means the eventual real positioning
        // still sees them intact.
        if (y === undefined) {
            console.log(`[LYRICS] active line ${activeLine} not measured yet, waiting for its layout`);
            return;
        }
        // Was 0.32 (a third of the way down) — with only a few short lines
        // around the active one (typical for this box's height), anchoring
        // near the top third left most of the box empty below it, since
        // there usually isn't enough surrounding lyric text to fill the
        // rest of the frame either way. The box is exactly the same size as
        // the cover art it swaps places with, so centering the active line
        // instead means the used/empty space splits evenly top and bottom —
        // matching how the cover fills that box symmetrically, which is the
        // actual ask ("symmetrical around the song cover").
        lyricsScrollRef.current?.scrollTo({ y: Math.max(0, y - (width - 56) * 0.5), animated: !skipAnimation });
        wasShowingLyricsRef.current = true;
        lyricsJustJumpedRef.current = false;
        markLyricsPlaced();
    }, [activeLine, rawActiveLine, showingLyrics, lyricsManualScroll, lyricsLayoutVersion]);

    // Re-sync only when needed: on mount, on play/pause toggling, on a track
    // switch, or if the running animation has drifted noticeably from what
    // the real progress hook reports (e.g. after a system hiccup). Anything
    // else, the animation just keeps running uninterrupted at real-time speed
    // — no restart, no stutter.
    const lastSyncedTrackIdRef = useRef(currentTrack?.id);
    const discResyncTimer = useRef(null);
    // While a finger is on the disc the song's speed is the finger's, so the
    // bar's own timer would be wrong: it follows the real position instead
    // (quick readings), and takes over again a moment after the finger lifts.
    const syncPausedUntil = useRef(0);
    useEffect(() => {
        if (!discHeld) return;
        stopAnim();
        syncPausedUntil.current = Number.MAX_SAFE_INTEGER;
        let cancelled = false;
        const songId = currentTrack?.id;
        const follow = () => AudioEngine.getProgress().then((p) => {
            if (cancelled || !(p?.duration > 0)) return;
            if (songId && p.id && p.id !== songId) return;   // a reading for the other song
            const r = Math.max(0, Math.min(1, p.position / p.duration));
            animPctValueRef.current = r;
            animPct.setValue(r);
        }).catch(() => { });
        follow();
        const id = setInterval(follow, 90);
        return () => {
            cancelled = true;
            clearInterval(id);
            // Let the scratch finish ending, then restart the bar from the exact spot.
            syncPausedUntil.current = Date.now() + 300;
            clearTimeout(discResyncTimer.current);
            discResyncTimer.current = setTimeout(() => {
                if (discHeldRef.current) return;
                AudioEngine.getProgress().then((p) => {
                    if (discHeldRef.current || !(p?.duration > 0)) return;
                    if (songId && p.id && p.id !== songId) return;   // a reading for the other song
                    syncPausedUntil.current = 0;
                    startRealTimeAnim(Math.max(0, Math.min(1, p.position / p.duration)), true);
                }).catch(() => { syncPausedUntil.current = 0; });
            }, 300);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [discHeld]);
    useEffect(() => {
        if (dragRatio !== null) return; // scrubbing owns the value right now
        if (discHeld || Date.now() < syncPausedUntil.current) return; // the disc is being scratched (or just let go)
        const trackChanged = lastSyncedTrackIdRef.current !== currentTrack?.id;
        // A reading for the other song (around a crossfade's song change) says
        // nothing about this one: leave the bar alone until a real one comes.
        if (progress.stale && !trackChanged) return;
        lastSyncedTrackIdRef.current = currentTrack?.id;
        // Same fix as MiniPlayer: always stop on pause regardless of drift,
        // since a drift-gated check skips the stop() call whenever drift
        // happens to be near-zero at the moment of pausing — which is the
        // normal case, since pausing is immediate.
        if (!isPlaying) {
            stopAnim();
            // A song change while paused (skip, restore, queue tap) must
            // start the bar fresh too. `pct` is still the OLD song's value
            // until the next poll, which left the bar parked at the old spot.
            // Parked where the bar is, unless the real position is clearly
            // somewhere else (the app was away and the song moved, e.g. after
            // a Bluetooth connection): then it goes there.
            const farOff = Math.abs(pct - animPctValueRef.current) * (progress.duration || 0) > 1;
            const startPct = trackChanged ? 0 : (farOff ? pct : animPctValueRef.current);
            animPct.setValue(startPct);
            animPctValueRef.current = startPct;
            // `pct` can be up to 500ms old at the instant of a pause (lock
            // screen, Control Center, headphones). Read the exact position
            // so the frozen bar sits where playback really stopped.
            const trackAtPause = currentTrack?.id;
            AudioEngine.getProgress().then(p => {
                if (lastSyncedTrackIdRef.current !== trackAtPause || !(p?.duration > 0)) return;
                const exact = Math.max(0, Math.min(1, p.position / p.duration));
                animPct.setValue(exact);
                animPctValueRef.current = exact;
            }).catch(() => { });
            return;
        }
        if (trackChanged) {
            // Real bug found via screen recording during crossfade: a track
            // change can land in a render where `pct` is a stale/mismatched
            // value from a different song — `progress` (position/duration)
            // comes from a separate 500ms poll and can lag one tick behind
            // `currentTrack` updating, and during a crossfade specifically,
            // native briefly reports the OUTGOING track's position paired
            // with the INCOMING track's duration (see AudioEngine.swift's
            // getProgress — currentIndex already points at the incoming
            // track for the whole crossfade, while position still tracks
            // the outgoing node until the handoff completes). Trusting
            // `pct` here is what made the bar briefly jump to some unrelated
            // high position right as the crossfade handed off, before
            // snapping back down once a fresh poll landed. Resetting
            // straight to 0 instead — a track change always starts the
            // visual bar fresh anyway, same as `justSwitched` already does
            // for the position text above — never shows that wrong
            // intermediate value; the very next real poll corrects it via
            // the ordinary drift check below, same as always.
            console.log(`[BAR] track changed: bar reset to 0, last poll said ${(progress.position || 0).toFixed(1)}s of ${(progress.duration || 0).toFixed(1)}s`);
            // The new song may already be a few seconds in (a crossfade flips the
            // display halfway through). Ask for the real spot and start the bar
            // THERE, instead of at 0 and then jumping. Only if no usable answer
            // comes back quickly does the bar fall back to 0.
            // The old song's bar is cleared at once (it used to keep running for up to a
            // quarter second after a skip while the real spot was being asked for).
            const trackAtChange = currentTrack?.id;
            const idAtChange = currentTrack?.id;
            let settled = false;
            let zeroed = false;
            // The engine pushes a position about every quarter second, so the newest one already describes the new
            // song (a crossfade announces it halfway through). Used right now, synchronously: the bar goes straight
            // from the old song to the new song's real spot, without a stop at 0 and without waiting for a round trip.
            const lp = peekLastProgress();
            if (lp && lp.duration > 0 && idAtChange && lp.id === idAtChange && Date.now() - lp.at < 1200 && lp.position <= 40) {
                const adv = isPlaying ? ((Date.now() - lp.at) / 1000) * (playbackRate || 1) : 0;
                const pos = Math.min(lp.duration, lp.position + adv);
                settled = true;
                console.log(`[BAR] seeded from the engine's last reading: ${pos.toFixed(2)}s (reading ${Date.now() - lp.at}ms old)`);
                setSwitchProg({ position: pos, duration: lp.duration });
                startRealTimeAnim(Math.max(0, Math.min(1, pos / lp.duration)), true, lp.duration);
                return;
            }
            // No reading for the new song yet. A crossfade announces the new song halfway through, so it is already about
            // half a crossfade in (a song that ended by itself uses the end-of-track length). Start the bar THERE rather
            // than at 0; the real position replaces it as soon as it arrives (a few tens of ms), and for a plain song start
            // that is a move back of a fraction of a percent at most.
            const wasNearEnd = animPctValueRef.current > 0.9;
            const estSec = (crossfadeEnabled && isPlaying) ? ((wasNearEnd ? crossfadeDurationEndOfTrack : crossfadeDuration) || 0) / 2 : 0;
            const estDur = currentTrack?.duration || progress.duration || 0;
            const estPct = estDur > 0 ? Math.max(0, Math.min(1, estSec / estDur)) : 0;
            console.log(`[BAR] no matching reading yet (last: ${lp ? `${lp.id === idAtChange ? 'same song' : 'other song'}, ${Date.now() - lp.at}ms old` : 'none'}); starting at the estimated ${estSec.toFixed(2)}s`);
            stopAnim();
            animPct.setValue(estPct);
            animPctValueRef.current = estPct;
            // The bar waits at 0 only briefly; the real spot is asked for again every 120 ms
            // (up to ~1.5 s) so an answer that was not ready yet, or still described the other song,
            // still lands soon, instead of the bar sitting at 0 and then popping in later.
            const toZero = () => { if (settled || zeroed || lastSyncedTrackIdRef.current !== trackAtChange) return; zeroed = true; startRealTimeAnim(estPct, true, estDur); };
            setTimeout(toZero, 250);
            let attempts = 0;
            const trySeed = () => {
                if (settled || lastSyncedTrackIdRef.current !== trackAtChange) return;
                const retry = () => { if (++attempts < 12) setTimeout(trySeed, 120); else toZero(); };
                AudioEngine.getProgress().then(p => {
                    if (settled || lastSyncedTrackIdRef.current !== trackAtChange) return;
                    const usable = p?.duration > 0 && !(idAtChange && p.id && p.id !== idAtChange) && p.position <= p.duration && p.position <= 40;
                    if (!usable) { retry(); return; }
                    settled = true;
                    setSwitchProg({ position: p.position, duration: p.duration });
                    startRealTimeAnim(Math.max(0, Math.min(1, p.position / p.duration)), true, p.duration);
                }).catch(retry);
            };
            trySeed();
            return;
        }
        // Drift is judged in SECONDS now. 2% of the song was 3-4 seconds on
        // a normal track, which is what let the bar sit visibly wrong
        // after a skip, resume or outside pause before it corrected.
        // + = the bar is ahead of the sound. Right after a start (play, song
        // change) the audio position is still settling, so a bigger gap is
        // tolerated; later a bar that is ahead is left alone until it is
        // clearly off (a backward jump is the visible kind of glitch).
        const aheadSec = (barPctNow() - pct) * (progress.duration || 0);
        const inGrace = Date.now() < barGraceUntil.current;
        const tooFarAhead = aheadSec > (inGrace ? 1.5 : 1.2);
        const tooFarBehind = -aheadSec > (inGrace ? 1.5 : 0.4);
        // (the bar's running speed already follows playbackRate: see startRealTimeAnim)
        if (!animRunRef.current || tooFarAhead || tooFarBehind) {
            if (animRunRef.current) console.log(`[BAR] resync: bar was ${aheadSec.toFixed(1)}s ahead, poll says ${(progress.position || 0).toFixed(1)}s of ${(progress.duration || 0).toFixed(1)}s`);
            startRealTimeAnim(pct, !animRunRef.current);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [progress.position, isPlaying, currentTrack?.id, playbackRate, discHeld]);

    // Safety net: a seek preview that nothing has cleared for 4 s is dropped,
    // so the time text and the bar can never stay frozen at a spot.
    useEffect(() => {
        if (dragRatio === null) return;
        const t = setTimeout(() => { pendingSeekRatioRef.current = null; setDragRatio(null); }, 4000);
        return () => clearTimeout(t);
    }, [dragRatio]);

    // A different song means any seek or drag overlay belonged to the old one.
    // Without this a seek to the very end that crossfades into the next song
    // left the bar parked at that spot (e.g. 1:39 of 1:40) on the new song.
    const overlayTrackRef = useRef(currentTrack?.id);
    useEffect(() => {
        if (overlayTrackRef.current === currentTrack?.id) return;
        overlayTrackRef.current = currentTrack?.id;
        pendingSeekRatioRef.current = null;
        clearTimeout(clearDragTimer.current);
        clearTimeout(stuckSafetyTimer.current);
        setDragRatio(null);
    }, [currentTrack?.id]);

    // Clears the post-seek drag overlay once the polled position actually
    // agrees with where we told native to seek to — see the commit branch
    // in onScrub above for why this replaced a fixed timer. Independent of
    // the drift-correction effect above (which stays disabled the whole
    // time dragRatio is non-null, so the two can't fight each other).
    useEffect(() => {
        if (pendingSeekRatioRef.current === null) return;
        if (Math.abs(pct - pendingSeekRatioRef.current) < 0.02) {
            pendingSeekRatioRef.current = null;
            clearTimeout(clearDragTimer.current);
            setDragRatio(null);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [Math.round(pct * 200)]);

    useEffect(() => {
        return () => { stopAnim(); clearTimeout(stuckSafetyTimer.current); clearTimeout(clearDragTimer.current); clearTimeout(discResyncTimer.current); };
    }, []);

    // While the screen is off the native bar animation stops, but the clock the drift check uses keeps going, so
    // on waking the bar looked "on track" and stayed far behind the time text until the next song. On every wake
    // the running animation is dropped; the next position reading starts it again from the real spot.
    // The bar is restarted at once from the engine's answer (and again once the 450 ms stop below has passed), instead
    // of sitting still until the next position poll arrives, which took one to two seconds after waking.
    const startAnimRef = useRef(null);
    startAnimRef.current = startRealTimeAnim;
    useEffect(() => {
        let t = null;
        let t2 = null;
        const seed = () => {
            AudioEngine.getProgress().then(p => {
                if (!p || !(p.duration > 0) || p.position > p.duration) return;
                if (p.id && nowIdRef.current && p.id !== nowIdRef.current) return;
                startAnimRef.current?.(Math.max(0, Math.min(1, p.position / p.duration)), true, p.duration);
            }).catch(() => { });
        };
        const sub = AppState.addEventListener('change', (st) => {
            if (st !== 'active') return;
            stopAnim();
            seed();
            clearTimeout(t); clearTimeout(t2);
            t = setTimeout(() => { stopAnim(); }, 450);
            t2 = setTimeout(seed, 520);
        });
        return () => { sub.remove(); clearTimeout(t); clearTimeout(t2); };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Both move with transforms so they can run on the native side.
    const fillX = useMemo(() => animPct.interpolate({ inputRange: [0, 1], outputRange: [-barW, 0] }), [animPct, barW]);
    const thumbX = useMemo(() => animPct.interpolate({ inputRange: [0, 1], outputRange: [0, barW] }), [animPct, barW]);
    const skipIconColor = base.textDim; // fixed regardless of ACCENT (not base) — still needs to adapt light/dark

    // Shuffle/loop previously swapped color INSTANTLY on state change while
    // TouchableOpacity's own built-in press-dim (opacity 1 -> 0.2 -> 1) was
    // still running — the color jump landing mid-dim is what read as "goes
    // dark, goes darker, goes back up" (three visible stages) instead of one
    // smooth motion like the skip buttons (whose color never changes, only
    // opacity does). Animating the color itself in step with the same kind
    // of timing lets both properties move together as one transition.
    // Duration bumped from 120 -> 180ms per feedback ("slightly longer
    // fade"). Kept as one constant so the press-time trigger below and the
    // fallback useEffect can't drift apart from each other.
    // Just a quick fade between dark (off) and light (on). No press-dim, no
    // other motion. A tap within 250ms of the last one on the same button is
    // ignored, so a double tap counts once and the button never shows two
    // changes while only one registered.
    const SIDE_BTN_FADE_MS = 120;
    const SIDE_BTN_IGNORE_MS = 250;
    const shuffleAnim = useRef(new Animated.Value(shuffleOn ? 1 : 0)).current;
    const loopAnim = useRef(new Animated.Value(singleLoop ? 1 : 0)).current;
    const shuffleTargetRef = useRef(shuffleOn ? 1 : 0);
    const loopTargetRef = useRef(singleLoop ? 1 : 0);
    const animateSideBtn = (anim, targetRef, to) => {
        if (targetRef.current === to) return;
        targetRef.current = to;
        Animated.timing(anim, { toValue: to, duration: SIDE_BTN_FADE_MS, easing: Easing.out(Easing.quad), useNativeDriver: false }).start();
    };
    // Also follows changes that come from somewhere else (restoring a session).
    useEffect(() => { animateSideBtn(shuffleAnim, shuffleTargetRef, shuffleOn ? 1 : 0); }, [shuffleOn]);
    useEffect(() => { animateSideBtn(loopAnim, loopTargetRef, singleLoop ? 1 : 0); }, [singleLoop]);
    const shuffleColor = shuffleAnim.interpolate({ inputRange: [0, 1], outputRange: [offColor, theme.accent] });
    const loopColor = loopAnim.interpolate({ inputRange: [0, 1], outputRange: [offColor, theme.accent] });

    const lastTapRef = useRef({ shuffle: 0, loop: 0 });
    const onPressShuffle = () => {
        const now = Date.now();
        if (now - lastTapRef.current.shuffle < SIDE_BTN_IGNORE_MS) return;
        lastTapRef.current.shuffle = now;
        animateSideBtn(shuffleAnim, shuffleTargetRef, shuffleTargetRef.current ? 0 : 1);
        // The queue rebuild is heavy, so it starts once the quick fade is done.
        setTimeout(() => toggleShuffle(), SIDE_BTN_FADE_MS + 10);
    };
    const onPressLoop = () => {
        const now = Date.now();
        if (now - lastTapRef.current.loop < SIDE_BTN_IGNORE_MS) return;
        lastTapRef.current.loop = now;
        animateSideBtn(loopAnim, loopTargetRef, loopTargetRef.current ? 0 : 1);
        toggleSingleLoop();   // one cheap call: applied right at the tap
    };

    // The top edge is TOP_PAD, the same as the other screens' bars. It used the phone's status bar height + 6, which sat a few points lower on some phones.
    return (
        <ScreenBackground ownImage style={[s.container, { paddingTop: TOP_PAD }]}>
            <GradientCap color={theme.accent} height={68} style={{ borderBottomLeftRadius: 16, borderBottomRightRadius: 16, opacity: 0.5 }} />

            <View style={s.topBar}>
                {/* no empty slot when the arrow is off, so the title centers between the left edge and the icons.
                    (Keep comments on their own line: text after a } on the same line becomes a stray string in the View and crashes.) */}
                {playerBtns.back
                    ? <TouchableOpacity {...HOLD} onPress={() => navigation.goBack()} hitSlop={HIT} style={s.topBtn}>
                        <Text style={[s.topIcon, { color: theme.accent }]}>↓</Text>
                    </TouchableOpacity>
                    : null}
                {playerBtns.label
                    ? <Text style={[s.topLabel, { color: theme.accent }]} numberOfLines={1}>{(queueSource && currentTrack?.id === queueSource.id ? queueSource.name : null) ?? (currentPlaylist?.name && (!currentPlaylist.songs || currentPlaylist.songs.some(x => x.id === currentTrack?.id)) ? currentPlaylist.name : null) ?? homePlaylistName ?? 'Now Playing'}</Text>
                    : <View style={{ flex: 1 }} />}
                <View style={{ flexDirection: 'row', gap: 6 }}>
                    {/* EQ used to be hidden here with a comment saying
                        react-native-track-player didn't support real audio
                        EQ — true when that comment was written, but the
                        engine was replaced with the custom AudioEngine
                        (which DOES support EQ) several rounds ago and this
                        was never un-hidden. */}
                    {playerBtns.sleep && <TouchableOpacity {...HOLD} onPress={() => setShowSleepTimer(true)} hitSlop={HIT} style={s.topBtn}>
                        <MoonIcon size={19} color={(sleepTimerEndAt || sleepAtTrackEnd) ? theme.accent : offColor} />
                    </TouchableOpacity>}
                    {playerBtns.speed && <TouchableOpacity {...HOLD} onPress={() => setShowSpeed(true)} hitSlop={HIT} style={s.topBtn}>
                        <Text style={[s.eqTag, { color: Math.abs(playbackRate - 1) > 0.001 ? theme.accent : offColor }]}>{formatSpeed(playbackRate)}</Text>
                    </TouchableOpacity>}
                    {playerBtns.eq && <TouchableOpacity {...HOLD} onPress={() => setShowEQ(true)} hitSlop={HIT} style={s.topBtn}>
                        <Text style={[s.eqTag, { color: theme.accent }]}>EQ</Text>
                    </TouchableOpacity>}
                    {playerBtns.queue && <TouchableOpacity {...HOLD} onPress={() => setShowQueue(true)} hitSlop={HIT} style={s.topBtn}>
                        <MenuBarsIcon size={20} color={theme.accent} />
                    </TouchableOpacity>}
                </View>
            </View>

            {/* Art, then info+progress kept close together, then controls —
                evenly spaced across whatever room is left so nothing bunches
                up on a taller screen, instead of one big empty gap. */}
            <View style={s.middle}>
                {/* The visualizer behind the controls: from halfway between the bottom of the cover and the top of
                    the title, across the whole screen, down to the bottom. Drawn first, so everything else sits on it. */}
                {playerVizBehind && !performanceMode && vizTop != null ? (
                    <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: vizTop, bottom: 0 }}>
                        <SongVisualizer color={theme.accent} mode="pill" radius={0} />
                    </View>
                ) : null}
                {/* Cover and lyrics are now separate boxes sharing the same
                     slot (absolute-positioned over each other), not the
                     lyrics view nested inside the cover's own box —
                     previously the lyrics inherited the cover box's
                     background/shadow (a slightly lighter gray, meant to
                     read as a raised card of art), which looked wrong for
                     plain text. Lyrics use the screen's own background
                     instead, no shadow. */}
                <View style={[s.artWrap, { paddingTop: 20 }]} onLayout={(e) => { vizLay.current.artBottom = e.nativeEvent.layout.y + e.nativeEvent.layout.height; recomputeVizTop(); }}>
                    <View style={{ width: width - 56, height: width - 56 }}>
                        <Animated.View style={[StyleSheet.absoluteFill, { opacity: coverFade }]} pointerEvents={showingDisc || showingLyrics ? 'none' : 'auto'}>
                        <View style={{ flex: 1 }}>
                        {showPlayerCover && (
                            // The whole box (background/shadow/rounded corners) now
                            // fades with lyricsFade too, not just the artwork inside
                            // it — previously only the inner content faded, so the
                            // box's own dark background + shadow stayed visible as a
                            // flat square sitting behind the lyrics text. Fully
                            // transparent (and non-interactive) once lyrics are showing.
                            //
                            // New "Cover Shadow" setting: s.art itself has
                            // overflow:'hidden' (needed to clip the artwork/rounded
                            // corners), which also clips any shadow applied directly
                            // to it — a shadow property sitting right there in s.art's
                            // own style was actually dead/invisible for that reason.
                            // When the setting's on, wrap in a second Animated.View
                            // that carries ONLY the shadow (no overflow:hidden) at the
                            // same squircle radius as the cover itself, so it works
                            // identically for rounded or square cover_shape and simply
                            // isn't rendered at all — not just invisible, actually
                            // absent — whenever showPlayerCover is off, same as the
                            // cover art it surrounds.
                            // Real bug found here: this override always set the
                            // wrapper's shadow to the theme's ACCENT color, so
                            // "shadow" was actually a colored glow (purple, etc.)
                            // instead of a real dark drop shadow — coverShadowWrap's
                            // own base style already has the correct shadowColor
                            // ('#000'), same idea as the lyrics text using a dark
                            // shadow for legibility, not an accent-colored one.
                            <Animated.View style={coverShadow ? [s.coverShadowWrap, { borderRadius: squircle(width - 56, coverShape) }, ] : null}>
                                {/* Card-style outline, like the playlist cards: a band of card color
                                    behind the cover, same thickness all the way round. */}
                                {playerOutline && (
                                    <View pointerEvents="none" style={[{ position: 'absolute', top: -3, left: -3, right: -3, bottom: -3, backgroundColor: base.surface, borderRadius: cardRadius(width - 56, 3, coverShape) }]} />
                                )}
                                <Animated.View
                                    style={[s.art, { backgroundColor: base.surface, shadowColor: theme.accent, borderRadius: squircle(width - 56, coverShape) }, ]}
                                    pointerEvents={showingLyrics ? 'none' : 'auto'}
                                >
                                    {artwork
                                        ? <Image key={artwork} source={{ uri: artwork }} style={s.artImg} resizeMode="cover" />
                                        : null
                                    }
                                    {playerVizCover && !performanceMode && !vizHold ? <SongVisualizer color={theme.accent} mode="cover" size={width - 56} radius={squircle(width - 56, coverShape)} /> : null}
                                </Animated.View>
                            </Animated.View>
                        )}
                        </View>
                        </Animated.View>
                        <Animated.View ref={discAreaRef} onLayout={measureDiscArea} style={[StyleSheet.absoluteFill, { opacity: discFade }]} pointerEvents={showingDisc ? 'auto' : 'none'}>
                            {djDisc && (
                                <DJDisc
                                    size={width - 56}
                                    artwork={artwork}
                                    accent={theme.accent}
                                    shadow={coverShadow}
                                    outline={playerOutline}
                                    outlineColor={base.surface}
                                    spinDegPerSec={discRpmValue * 6 * (playbackRate || 1)}
                                    scratchDegPerSec={discRpmValue * 6}
                                    discType={djDiscType}
                                    placeholderColor={base.surface}
                                    assist={djDiscAssist}
                                    fadeBusy={fadeBusy}
                                    spinOn={djDiscSpin}
                                    touchOn={djDiscTouch}
                                    isPlaying={isPlaying}
                                    visible={showingDisc}
                                    trackKey={currentTrack?._qid ?? currentTrack?.id}
                                    active={discActive}
                                    position={progress.position}
                                    duration={progress.duration}
                                    endGuard={scratchEndGuard}
                                    startGuard={scratchStartGuard}
                                    onTouching={setDiscTouching}
                                />
                            )}
                        </Animated.View>
                        {lyricsData && (
                            <Animated.View
                                // Real bug found here: top/bottom -60 made this
                                // taller than (and offset 60px above) the cover art
                                // box it's meant to replace visually — the cover is a
                                // plain (width-56) square in normal flow, this was
                                // absolutely positioned to start 60px above THAT and
                                // extend 60px past its bottom. That's exactly "lyrics
                                // aren't where they're supposed to be, shouldn't be
                                // further up" and "should be the same size as the
                                // cover" — matching the art's own footprint exactly
                                // (top: 0, height: width-56) instead of guessing at a
                                // taller offset box fixes both at once.
                                style={[{ position: 'absolute', top: 0, height: width - 56, left: 0, right: 0 }, { opacity: lyricsOpacity, overflow: 'hidden' }]}
                                pointerEvents={showingLyrics ? 'auto' : 'none'}
                            >
                                <Animated.ScrollView
                                    ref={lyricsScrollRef}
                                    style={{ flex: 1 }}
                                    // Half the box above the first line and below the last one (in points: a percent padding is
                                    // a share of the WIDTH, which was 40 percent here, so the first line sat above the middle and
                                    // the view could never put it, or the last line, where every other line sits). 7 is a row's margin.
                                    contentContainerStyle={[s.lyricsContent, { paddingTop: (width - 56) * 0.5 - 7, paddingBottom: (width - 56) * 0.5 }]}
                                    showsVerticalScrollIndicator={false}
                                    scrollEnabled={showingLyrics && !lyricsScrollLocked}
                                    onScroll={Animated.event(
                                        [{ nativeEvent: { contentOffset: { y: lyricsScrollY } } }],
                                        { useNativeDriver: true }
                                    )}
                                    scrollEventThrottle={16}
                                    onContentSizeChange={(_w, h) => {
                                        // Scrolling before the content has its height is clamped to the top:
                                        // while the lyrics are still hidden, place again once it is known.
                                        if (h > 0 && !lyricsPlacedRef.current) setLyricsLayoutVersion(v => v + 1);
                                    }}
                                    onScrollBeginDrag={() => {
                                        if (lyricsResyncTimer.current) clearTimeout(lyricsResyncTimer.current);
                                        setLyricsManualScroll(true);
                                    }}
                                    onScrollEndDrag={armResyncTimer}
                                    onMomentumScrollEnd={armResyncTimer}
                                >
                                    {/* scrollEnabled above now also respects the
                                        "Unscrollable Lyrics" setting — when it's on,
                                        this stays non-scrollable so the same swipe
                                        that closes the player elsewhere also works
                                        over the lyrics panel instead of scrolling
                                        through the text. Off by default: the
                                        swipe-to-dismiss gesture is limited (via
                                        gestureResponseDistance, set from the controls
                                        row below) to starting above the control row,
                                        and a RNGH-composed ScrollView generally yields
                                        to a surrounding pan gesture at its own scroll
                                        bounds anyway. */}
                                    <React.Fragment key={lyricsSetKey}>{lyricsData.map((line, i) => {
                                        if (!line.text) {
                                            if (!isGapLine(i)) return null;   // an empty timestamp: nothing is drawn (no "...")
                                            return <View key={i} onLayout={(e) => { lyricsRowYRef.current.set(i, e.nativeEvent.layout.y); lyricsRowHRef.current.set(i, e.nativeEvent.layout.height); bumpLyricsLayout(); }} style={{ height: 34, marginVertical: 7 }} />;
                                        }
                                        // Spotify-style: the lines themselves fade out toward the top
                                        // and bottom edge of the box (no dark box over them). A row's
                                        // Y comes from its onLayout; minus the live scroll offset it is
                                        // the position inside the box, and the opacity is interpolated
                                        // from the CENTER of each visual row of text, so every row of
                                        // text gets its own step of the fade and a line that wraps onto
                                        // two or three rows fades as a gradient, not as one flat block.
                                        // Before the first layout the Y is unknown: fully visible.
                                        const lineY = lyricsRowYRef.current.get(i);
                                        const boxH = width - 56;
                                        const FADE = 72;
                                        const ROW_H = 34; // s.lyricLine's lineHeight
                                        const fadeAt = (centerY) => (lineY === undefined ? 1 : lyricsScrollY.interpolate({
                                            inputRange: [centerY - boxH, centerY - boxH + FADE, centerY - FADE, centerY],
                                            outputRange: [0, 1, 1, 0],
                                            extrapolate: 'clamp',
                                        }));
                                        const onRowLayout = (e) => { lyricsRowYRef.current.set(i, e.nativeEvent.layout.y); lyricsRowHRef.current.set(i, e.nativeEvent.layout.height); bumpLyricsLayout(); };
                                        const textColor = i === activeLine ? lyricActiveColor : lyricIdleColor;
                                        const shadow = { textShadowColor: base.bg, textShadowOffset: { width: 0, height: 0 }, textShadowRadius: 4 };
                                        const rows = lyricsLinesRef.current.get(i);
                                        if (rows && rows.length > 1 && lineY !== undefined) {
                                            return (
                                                <View key={i} onLayout={onRowLayout} style={{ marginVertical: 7 }}>
                                                    {rows.map((rowText, k) => (
                                                        <Animated.Text
                                                            key={k}
                                                            style={[s.lyricLine, shadow, { marginVertical: 0, color: textColor, opacity: fadeAt(lineY + k * ROW_H + ROW_H / 2) }, i === activeLine && s.lyricLineActive]}
                                                        >
                                                            {rowText}
                                                        </Animated.Text>
                                                    ))}
                                                </View>
                                            );
                                        }
                                        return (
                                            <Animated.Text
                                                key={i}
                                                onLayout={onRowLayout}
                                                onTextLayout={(e) => {
                                                    // Wrapped line: remember what each visual row says, then draw
                                                    // the row as separate pieces (above). Same width and line
                                                    // height as before, so nothing moves.
                                                    const ls = e.nativeEvent?.lines;
                                                    if (!ls || ls.length < 2 || lyricsLinesRef.current.has(i)) return;
                                                    const texts = ls.map(l => String(l.text || '').replace(/\s+$/, ''));
                                                    if (texts.some(t => !t)) return;
                                                    lyricsLinesRef.current.set(i, texts);
                                                    if (!linesBumpPending.current) {
                                                        linesBumpPending.current = true;
                                                        requestAnimationFrame(() => { linesBumpPending.current = false; setLyricsLinesVersion(v => v + 1); });
                                                    }
                                                }}
                                                style={[s.lyricLine, shadow, { color: textColor, opacity: fadeAt(lineY + ROW_H / 2) }, i === activeLine && s.lyricLineActive]}
                                            >
                                                {line.text}
                                            </Animated.Text>
                                        );
                                    })}</React.Fragment>
                                </Animated.ScrollView>
                            </Animated.View>
                        )}
                        {lyricsArrows && lyricsData ? (
                            // Fixed arrows at the left and right edge of the SCREEN (the box is inset 28 on each side),
                            // at the height where the active line always sits. They do not move with the lyrics. Accent
                            // coloured while words are playing, dim while the line is blank or before the first line.
                            <Animated.View pointerEvents="none" style={{ position: 'absolute', top: 0, height: width - 56, left: -28, right: -28, opacity: lyricsOpacity }}>
                                {(() => {
                                    const color = (activeLine >= 0 && lyricsData[activeLine]?.text) ? lyricActiveColor : lyricIdleColor;
                                    const top = (width - 56) * 0.5 + 17 - 19;
                                    return (
                                        <>
                                            <Text style={[s.lyricArrow, { left: 2, top, color }]}>{'\u25B8'}</Text>
                                            <Text style={[s.lyricArrow, { right: 2, top, color }]}>{'\u25C2'}</Text>
                                        </>
                                    );
                                })()}
                            </Animated.View>
                        ) : null}
                    </View>
                </View>

                {/* Always-reserved slot, whether or not the button inside it
                     renders — otherwise `middle`'s space-evenly layout
                     recalculates every gap the moment a song with/without
                     lyrics loads, visibly shifting the title down (or up)
                     depending on whether this song happens to have an .lrc
                     file. The slot's height is fixed regardless. */}
                <View onLayout={(e) => { vizLay.current.wrapY = e.nativeEvent.layout.y; recomputeVizTop(); }}>
                    {/* Real cause of the toggle looking untouched by the
                         earlier margin tweak: it was a SEPARATE sibling of
                         trackInfoGroup, both direct children of `middle`,
                         which uses justifyContent: 'space-evenly' — that
                         inserts its own (much bigger) flexible gap between
                         every top-level child regardless of any marginTop
                         set on either one. Moving the toggle to be the
                         first child INSIDE trackInfoGroup instead of a
                         sibling before it means it's now part of the same
                         single flex item as the title, so the only thing
                         controlling their distance is the marginBottom set
                         here directly — no more competing flex gap. */}
                    <View style={[s.trackInfoGroup, { marginTop: 16 }]} onLayout={(e) => { vizLay.current.groupY = e.nativeEvent.layout.y; recomputeVizTop(); }}>
                    <View style={[s.lyricsToggleSlot, { marginBottom: 14 }, titleLines > 1 ? { transform: [{ translateY: -titleLineH }] } : null]}>
                        {(hasLyricsView || djDisc) && (
                            <TouchableOpacity {...HOLD} onPress={cycleView} style={s.lyricsToggleBtn}>
                                <Text style={[s.lyricsToggleText, { color: theme.accent }]}>
                                    {nextViewLabel}
                                </Text>
                            </TouchableOpacity>
                        )}
                    </View>
                    <View style={s.info} onLayout={(e) => { vizLay.current.infoY = e.nativeEvent.layout.y; recomputeVizTop(); }}>
                        <View style={{ flex: 1 }}>
                            {/* The slot is always ONE line tall (the invisible sizer
                                text), so the group's height never changes. The real
                                title sits on the slot's bottom edge and, when it
                                wraps, grows upward out of it. */}
                            <View style={{ marginBottom: 4 }}>
                                <Text style={[s.trackTitle, { marginBottom: 0, opacity: 0 }]} numberOfLines={1} accessible={false} importantForAccessibility="no-hide-descendants">{displayTitle}</Text>
                                <Text
                                    style={[s.trackTitle, { color: base.text, marginBottom: 0, position: 'absolute', left: 0, right: 0, bottom: 0 }]}
                                    numberOfLines={2}
                                    onTextLayout={(e) => {
                                        const ls = e.nativeEvent.lines;
                                        if (!ls || !ls.length) return;
                                        const n = ls.length > 1 ? 2 : 1;
                                        if (n !== titleLines) setTitleLines(n);
                                        const h = ls[0].height;
                                        if (h > 0 && Math.abs(h - titleLineH) > 0.5) setTitleLineH(h);
                                    }}
                                >{displayTitle}</Text>
                            </View>
                            <Text style={[s.trackArtist, { color: theme.accent }]} numberOfLines={1}>{displayArtist}</Text>
                        </View>
                        {showPlayCount && (
                            <Text style={[s.playCount, { color: base.textFaint, opacity: shownCount > 0 ? 1 : 0 }]}>{shownCount}×</Text>
                        )}
                    </View>

                    <View style={s.progressSection}>
                        <TapGestureHandler ref={tapRef} onHandlerStateChange={onTapStateChange} simultaneousHandlers={panRef}>
                            <PanGestureHandler
                                ref={panRef}
                                onGestureEvent={onProgressGestureEvent}
                                onHandlerStateChange={onProgressStateChange}
                                activeOffsetX={[-6, 6]}
                                failOffsetY={[-14, 14]}
                                simultaneousHandlers={tapRef}
                            >
                                <View
                                    ref={progressRef}
                                    style={s.progressTouch}
                                    onLayout={(e) => { const w = e.nativeEvent.layout.width; if (w > 0 && Math.abs(w - barW) > 0.5) setBarW(w); measureProgress(); }}
                                >
                                    <View style={[s.progressTrack, { backgroundColor: base.border, overflow: 'hidden' }]}>
                                        <Animated.View style={[s.progressFill, { width: barW, backgroundColor: theme.accent, transform: [{ translateX: fillX }] }]} />
                                    </View>
                                    <Animated.View style={[s.progressThumb, { left: 0, marginLeft: -8.5, backgroundColor: theme.accent, transform: [{ translateX: thumbX }] }]} />
                                </View>
                            </PanGestureHandler>
                        </TapGestureHandler>
                        <View style={s.times}>
                            {dragRatio !== null || justSwitched
                                ? <Text style={[s.time, { color: base.textFaint }]}>{fmt(dragRatio !== null ? dragRatio * progress.duration : switchProg.position)}</Text>
                                : <LiveTime position={progress.position} duration={progress.duration} playing={isPlaying} rate={playbackRate} style={[s.time, { color: base.textFaint }]} />}
                            <Text style={[s.time, { color: base.textFaint }]}>{fmt((justSwitched ? switchProg.duration : progress.duration) || knownDur)}</Text>
                        </View>
                    </View>
                </View>
                </View>

                <View
                    ref={controlsRef}
                    style={[s.controls, { paddingBottom: insets.bottom + 10 }]}
                    onLayout={() => {
                        // Shrinks the swipe-to-dismiss zone (App.js sets
                        // gestureResponseDistance to the full screen height,
                        // so the sheet can be dismissed by swiping from
                        // anywhere) so it stops right above this row instead
                        // of covering it too. Without this, a tap on
                        // play/skip/shuffle/loop that carries even a little
                        // downward motion — normal with a real finger — could
                        // get stolen by the outer dismiss gesture instead of
                        // registering as a press, or trigger an unwanted
                        // dismiss outright. measureInWindow needs the view
                        // already laid out, which onLayout guarantees.
                        controlsRef.current?.measureInWindow((x, y) => {
                            if (y > 0) { controlsYRef.current = y; applyDismissZone(); }
                        });
                    }}
                >
                    {/* activeOpacity was 1 — meaning zero dimming feedback on
                        touch-down. That's a native, immediate response
                        (TouchableOpacity's own gesture responder, no JS round
                        trip) — without it, the color fade (however fast) was
                        the ONLY acknowledgment a tap had landed, and that's
                        gated behind JS work even at its quickest. This gives
                        an instant visual response the moment the finger
                        touches down, independent of everything else. */}
                    <TouchableOpacity {...HOLD} onPress={onPressShuffle} style={s.sideBtn} hitSlop={HIT} activeOpacity={1}>
                        <ShuffleIcon size={35} color={shuffleColor} />
                    </TouchableOpacity>
                    <TouchableOpacity {...HOLD} onPress={() => skipWithRamp('prev')} style={s.skipBtn} hitSlop={HIT}>
                        <SkipPrevIcon size={38} color={skipIconColor} />
                    </TouchableOpacity>
                    <TouchableOpacity {...HOLD}
                        onPress={() => {
                            if (discHeldRef.current) return;   // the disc is being scratched: not now
                            setFadeBusy(true);
                            if (fadeBusyTimer.current) clearTimeout(fadeBusyTimer.current);
                            const done = () => {
                                if (fadeBusyTimer.current) clearTimeout(fadeBusyTimer.current);
                                fadeBusyTimer.current = setTimeout(() => setFadeBusy(false), 200);
                            };
                            Promise.resolve(isPlaying ? pauseWithRamp() : playWithRamp()).then(done, done);
                        }}
                        style={[s.playBtn, { backgroundColor: theme.accent, shadowColor: theme.accent }]}
                    >
                        {isPlaying ? <PauseIcon size={33} color={theme.onAccent} /> : <PlayIcon size={33} color={theme.onAccent} />}
                    </TouchableOpacity>
                    <TouchableOpacity {...HOLD} onPress={() => skipWithRamp('next')} style={s.skipBtn} hitSlop={HIT}>
                        <SkipNextIcon size={38} color={skipIconColor} />
                    </TouchableOpacity>
                    <TouchableOpacity {...HOLD} onPress={onPressLoop} style={s.sideBtn} hitSlop={HIT} activeOpacity={1}>
                        <LoopIcon size={35} color={loopColor} single={singleLoop} />
                    </TouchableOpacity>
                </View>
            </View>

            <EQModal visible={showEQ} onClose={() => setShowEQ(false)} />
            <QueueModal visible={showQueue} onClose={() => setShowQueue(false)} />
            <SleepTimerSheet visible={showSleepTimer} onClose={() => setShowSleepTimer(false)} />
            <PlaybackSpeedSheet visible={showSpeed} onClose={() => setShowSpeed(false)} />
        </ScreenBackground>
    );
}

const HIT = { top: 20, bottom: 20, left: 20, right: 20 };

const s = StyleSheet.create({
    container: { flex: 1 },
    // Was 12 — PlaylistDetailScreen's own topBar (the same row: back/down
    // arrow, title, shuffle, EQ, hamburger) uses 8. Same row, two different
    // edge insets depending on which screen you're looking at it from —
    // the back arrow and hamburger/EQ icons visibly shift a few pixels
    // left/right crossing between the two, which is what "buttons on the
    // music player vs outside it are not aligned" was pointing at.
    topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 8, marginBottom: 4 },
    // Matches PlaylistDetailScreen/AllSongsScreen's topBtn — was 44 here,
    // 40 there, 36 on All Songs: three different tap-target sizes for the
    // same EQ/queue controls, which is part of what made them look
    // misaligned crossing between screens even after the paddingHorizontal
    // fix below (see topBar comment).
    topBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
    eqTag: { fontSize: 16, fontWeight: "700" },
    topIcon: { fontSize: 26 },
    topLabel: { fontSize: 15, fontWeight: '500', flex: 1, textAlign: 'center' },
    middle: { flex: 1, justifyContent: 'space-evenly' },
    artWrap: { alignItems: 'center' },
    art: { width: width - 56, height: width - 56, backgroundColor: '#0f0f0f', justifyContent: 'center', alignItems: 'center', overflow: 'hidden', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.18, shadowRadius: 8 },
    // shadowOffset/Opacity/Radius above on `art` itself are dead weight —
    // `overflow:'hidden'` on that same view clips its own shadow on iOS, so
    // it was never actually visible. This is the real, visible one, one
    // step further out where nothing clips it. Deliberately a bit more
    // pronounced than art's old (invisible) values, since a shadow subtle
    // enough to match those wouldn't have been worth adding a setting for.
    // Was shadowRadius:16/offset:10/opacity:0.35 — a much heavier shadow
    // than anything else on this screen. Scaled down to roughly match the
    // lyrics' own textShadowRadius:4 glow instead of standing out as its
    // own much bigger effect.
    coverShadowWrap: { width: width - 56, height: width - 56, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.38, shadowRadius: 3.5, elevation: 4 },
    artImg: { width: '100%', height: '100%' },
    artNote: { fontSize: 80 },
    // Small text button matching the sort-label style used elsewhere
    // (Playlist/All Songs sort buttons) — plain text, no background, no
    // arrow, same visual weight as those.
    // Condensed and pulled up per feedback — was reading as a prominent
    // standalone button (large tap padding, bold weight, full accent
    // color); now smaller, thinner, and lighter so it sits closer to the
    // title instead of announcing itself as separate control.
    lyricsToggleSlot: { height: 28, justifyContent: 'flex-end', alignItems: 'center' },
    lyricsToggleBtn: { alignSelf: 'center', paddingHorizontal: 10, paddingVertical: 4 },
    lyricsToggleText: { fontSize: 12, fontWeight: '500', opacity: 0.7 },
    lyricsContent: { paddingHorizontal: 6 },
    // Was 700 base / 800 active — a real weight change between the two,
    // which shifts glyph widths enough to reflow line-wrapping right as a
    // line becomes active (Eric: "the boldness makes the lyrics have a
    // different layout because of like wrapping"). Both now render at the
    // same 800 weight always; active vs inactive is still clearly
    // distinguished by color/opacity alone (see the color/opacity props
    // where this style gets applied), just without the reflow.
    lyricArrow: { position: 'absolute', top: 0, fontSize: 26, lineHeight: 38, fontWeight: '700' },
    lyricLine: { fontSize: 24, lineHeight: 34, fontWeight: '800', textAlign: 'center', marginVertical: 7 },
    // Two fixes here per direct feedback:
    // 1. "too bolded, just a normal bold ideally, noticeable but not over
    //    the top" — was 900/26 (bigger jump, bigger size too). Dialed back
    //    to 800, same 24 size as idle lines.
    // 2. "bolding changes line wrap, words wrap differently than they were
    //    supposed to" — a heavier weight has wider glyphs, so switching a
    //    line's weight can genuinely shift where it wraps. Dropping the
    //    fontSize bump removes HALF of what was changing width (size and
    //    weight were compounding); keeping some weight difference from
    //    idle's 700 still risks a SMALLER version of the same reflow —
    //    700→800 is a much smaller jump than 700→900 was, but if lines
    //    still visibly reflow, the next step would be dropping the weight
    //    difference entirely and using color/glow alone for emphasis.
    lyricLineActive: { fontWeight: '800' },
    trackInfoGroup: {},
    info: { paddingHorizontal: 28, marginBottom: 10, flexDirection: 'row', alignItems: 'flex-start' },
    playCount: { color: '#444', fontSize: 13, fontWeight: '600', marginLeft: 10, marginTop: 2 },
    trackTitle: { color: '#f0f0f0', fontSize: 22, fontWeight: '700', marginBottom: 4, letterSpacing: -0.3 },
    trackArtist: { fontSize: 15, fontWeight: '500' },
    progressSection: { paddingHorizontal: 28 },
    progressTouch: { height: 44, justifyContent: 'center' },
    progressTrack: { height: 4, backgroundColor: '#1a1a1a', borderRadius: 2 },
    progressFill: { height: 4, borderRadius: 2 },
    progressThumb: { position: 'absolute', width: 17, height: 17, borderRadius: 8.5, top: 13.5 },
    times: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 },
    time: { color: '#3a3a3a', fontSize: 12 },
    controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12 },
    sideBtn: { width: 62, height: 62, alignItems: 'center', justifyContent: 'center' },
    skipBtn: { width: 70, height: 70, alignItems: 'center', justifyContent: 'center' },
    playBtn: { width: 84, height: 84, borderRadius: 42, justifyContent: 'center', alignItems: 'center', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 8 },
});
