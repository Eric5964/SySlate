import React, { useContext, useState, useEffect, useLayoutEffect, useCallback, useMemo, memo, useRef } from 'react';
import {
    View, Text, ScrollView, TouchableOpacity, Pressable, StyleSheet, StatusBar, Image, Alert, Dimensions, Animated, PanResponder, Easing, AppState,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useNavigation, useFocusEffect, useScrollToTop } from '@react-navigation/native';
import { LibraryContext } from '../context/LibraryContext';
import { useTheme } from '../context/ThemeContext';
import { usePreferences } from '../context/PreferencesContext';
import { squircle, cardRadius } from '../utils/squircle';
import DimPressable, { DIM_COLOR } from '../components/DimPressable';
import { pillPad, PILL_COVER, TOP_PAD, TOP_FADE, OVERLAY_HEADER, useMeasuredHeight } from '../utils/layout';
import TopBarBack from '../components/TopBarFade';
import {
    getPlaylistViewFormat, setPlaylistViewFormat,
    setPlaylistOrder,
    getPlaylistCovers, setPlaylistCover, persistCoverImage, shrinkOldPlaylistCovers,
} from '../utils/storage';
import { COVER_SHADOW } from '../utils/shadow';
import { playlistBackX } from '../utils/backSwipe';
import ScreenBackground from '../components/ScreenBackground';

const SCREEN_W = Dimensions.get('window').width;
const GRID_PADDING = 8;
const CELL_MARGIN = 5;
// Up and down spacing is a little larger than side to side, because a card
// reaches further past its playlist at the bottom than at the sides; this makes
// the gap between two cards the same going down as going across.
const CELL_MARGIN_V = 6.5;

// Fixed pixel math instead of percentage/aspectRatio-based sizing — that
// combination was behaving unpredictably (only ever showing part of a grid),
// so every sized element in this screen now computes its exact pixel size
// up front from the screen width.
function cellSize(cols) {
    const usable = SCREEN_W - GRID_PADDING * 2 - CELL_MARGIN * 2 * cols;
    return Math.floor(usable / cols);
}
const CELL_SIZES = { 2: cellSize(2), 3: cellSize(3) };

// Layout buttons: every icon is drawn (not typed) inside the same 18 by 18
// box, so they all look the same size and each one looks like its layout.
const ICON_BOX = 18;
function FormatIcon({ id, color }) {
    const box = { width: ICON_BOX, height: ICON_BOX };
    if (id === 'list') {
        return (
            <View style={[box, { justifyContent: 'space-between' }]}>
                {[0, 1, 2].map(i => <View key={i} style={{ height: 4, borderRadius: 2, backgroundColor: color }} />)}
            </View>
        );
    }
    if (id === 'list_art') {
        return (
            <View style={[box, { justifyContent: 'space-between' }]}>
                {[0, 1, 2].map(i => (
                    <View key={i} style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <View style={{ width: 5, height: 5, borderRadius: 1.5, backgroundColor: color }} />
                        <View style={{ flex: 1, height: 3, marginLeft: 2, borderRadius: 1.5, backgroundColor: color }} />
                    </View>
                ))}
            </View>
        );
    }
    const n = id === 'grid2' ? 2 : 3;
    const gap = n === 2 ? 2 : 2;
    const cell = (ICON_BOX - gap * (n - 1)) / n;
    return (
        <View style={[box, { justifyContent: 'space-between' }]}>
            {Array.from({ length: n }).map((_, r) => (
                <View key={r} style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    {Array.from({ length: n }).map((__, c) => (
                        <View key={c} style={{ width: cell, height: cell, borderRadius: n === 2 ? 2.5 : 1.5, backgroundColor: color }} />
                    ))}
                </View>
            ))}
        </View>
    );
}

const FORMATS = [
    { id: 'list', cols: 1 },
    { id: 'list_art', cols: 1 },
    { id: 'grid3', cols: 3 },
    { id: 'grid2', cols: 2 },
];

// Reordering needs each playlist's position on screen: every playlist reports where it sits
// (all of them are direct children of one container, so a playlist keeps its identity, and its
// already decoded cover, when the order changes).

// Memoized so the hold/drag state living in the parent doesn't re-render
// every visible row, only the one being held.
const WIGGLE_MS = 300;       // one full back-and-forth
const WIGGLE_STEPS = 16;
const CARD_INSET = 3;        // how far a grid card reaches past its playlist
const CARD_BOTTOM_EXTRA = 3; // the card is this much taller at the bottom, for the track count
const PlaylistRow = memo(function PlaylistRow({ item, index, format, numCols, cover, base, shape, showTitle, showCount, cardOn, arrowOn, shadowOn, isActive, isDragging, editing, anim, lift, onItemLayout, onPressIn, onPressOut, onPress, onRemoveCover }) {
    // Edit mode: every playlist wiggles, like the iOS home screen. The sway
    // is a pure sine (same distance each way, smooth at both ends, no
    // bounce), and each playlist starts at its own point in the cycle.
    // `phase` runs 0 to 1 forever; `on` fades the wiggle in and out.
    const phase = useRef(new Animated.Value(0)).current;
    const on = useRef(new Animated.Value(0)).current;
    const jiggling = !!editing && !isActive;
    useEffect(() => {
        if (!jiggling) {
            Animated.timing(on, { toValue: 0, duration: 120, easing: Easing.out(Easing.quad), useNativeDriver: true }).start(({ finished }) => { if (finished) phase.stopAnimation(); });
            return undefined;
        }
        phase.setValue(0);
        Animated.loop(Animated.timing(phase, { toValue: 1, duration: WIGGLE_MS, easing: Easing.linear, useNativeDriver: true })).start();
        Animated.timing(on, { toValue: 1, duration: 140, easing: Easing.out(Easing.quad), useNativeDriver: true }).start();
        return () => { phase.stopAnimation(); };
    }, [jiggling, phase, on]);
    const amp = format.startsWith('grid') ? (numCols === 3 ? 1.5 : 1.1) : 0.3;
    const offset = ((index * 37) % 100) / 100;   // each playlist starts at a different point
    const sway = useMemo(() => phase.interpolate({
        inputRange: Array.from({ length: WIGGLE_STEPS + 1 }, (_, k) => k / WIGGLE_STEPS),
        outputRange: Array.from({ length: WIGGLE_STEPS + 1 }, (_, k) => Math.sin(2 * Math.PI * (k / WIGGLE_STEPS + offset))),
    }), [phase, offset]);
    const jigDeg = useMemo(() => Animated.multiply(sway, on).interpolate({ inputRange: [-1, 1], outputRange: [`-${amp}deg`, `${amp}deg`] }), [sway, on, amp]);
    // Blank placeholder in the base color (no letters, no bright colors).
    const bg = base.surface;

    const art = cover
        ? <Image source={{ uri: cover }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
        : null;

    const wrapStyle = [
        { transform: [...anim.getTranslateTransform(), { scale: isActive ? lift : 1 }, { rotate: jigDeg }] },
        isDragging && isActive && s.lifted,
        // The picked-up playlist draws above every other one, including the
        // ones in its own row (the row itself is raised in RowCell).
        isActive && { zIndex: 100 },
    ];
    const handlers = {
        onPressIn: () => onPressIn(item, index),
        onPressOut: () => onPressOut(item, index),
        onPress: () => onPress(item, index),
    };
    const hasText = showTitle !== false || showCount !== false;
    // Small "-" while rearranging: asks first, then removes this playlist's cover picture.
    const minus = (editing && cover && onRemoveCover) ? (
        <Pressable
            onPressIn={() => onRemoveCover(item, true)}
            onPress={() => onRemoveCover(item, false)}
            hitSlop={8}
            style={[s.minus, { backgroundColor: base.surface, borderColor: base.border }]}
        >
            <View style={[s.minusBar, { backgroundColor: base.text }]} />
        </Pressable>
    ) : null;

    if (format.startsWith('grid')) {
        const size = CELL_SIZES[numCols];
        const r = squircle(size, shape);
        return (
            <Animated.View style={wrapStyle} onLayout={(e) => onItemLayout(index, e.nativeEvent.layout)}>
                <Pressable
                    style={[s.gridItem, { width: size, marginHorizontal: CELL_MARGIN, marginVertical: CELL_MARGIN_V }]}
                    {...handlers}
                >
                    {({ pressed }) => (<>
                    {cardOn && (
                        <View
                            pointerEvents="none"
                            style={[
                                s.card,
                                { top: -CARD_INSET, left: -CARD_INSET, right: -CARD_INSET, bottom: -(CARD_INSET + (hasText ? CARD_BOTTOM_EXTRA : 0)), backgroundColor: base.surface,
                                  borderTopLeftRadius: cardRadius(size, CARD_INSET, shape), borderTopRightRadius: cardRadius(size, CARD_INSET, shape),
                                  borderBottomLeftRadius: Math.round(cardRadius(size, CARD_INSET, shape) * 0.75), borderBottomRightRadius: Math.round(cardRadius(size, CARD_INSET, shape) * 0.75) },
                                shadowOn && COVER_SHADOW,
                            ]}
                        />
                    )}
                    <View style={[{ width: size, height: size, marginBottom: hasText ? CARD_INSET + CARD_BOTTOM_EXTRA : 0, borderRadius: r, backgroundColor: bg }, shadowOn && COVER_SHADOW]}>
                        <View style={[s.gridArt, { width: size, height: size, borderRadius: r }]}>{art}</View>
                        {pressed && !isActive ? <View pointerEvents="none" style={{ position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, borderRadius: r, backgroundColor: DIM_COLOR }} /> : null}
                        {minus}
                    </View>
                    {showTitle !== false && <Text style={[s.gridName, { color: base.text }]} numberOfLines={2}>{item.name}</Text>}
                    {showCount !== false && <Text style={[s.gridCount, { color: base.textFaint }]}>{item.songs.length} {item.songs.length === 1 ? 'track' : 'tracks'}</Text>}
                    </>)}
                </Pressable>
            </Animated.View>
        );
    }
    return (
        <Animated.View style={wrapStyle} onLayout={(e) => onItemLayout(index, e.nativeEvent.layout)}>
            <DimPressable
                fade={!cardOn}
                disabledDim={isActive}
                style={[s.row, { backgroundColor: cardOn ? base.surface : 'transparent' }, pillPad(format === 'list_art'), format === 'list_art' && { paddingRight: 12 }, cardOn && shadowOn && COVER_SHADOW]}
                {...handlers}
            >
                {format === 'list_art' && (
                    <View style={[s.listArt, { backgroundColor: bg, borderRadius: squircle(PILL_COVER, shape) }, shadowOn && COVER_SHADOW]}>
                        <View style={{ width: PILL_COVER, height: PILL_COVER, overflow: 'hidden', borderRadius: squircle(PILL_COVER, shape) }}>{art}</View>
                    </View>
                )}
                <View style={{ flex: 1 }}>
                    {showTitle !== false && <Text style={[s.rowName, { color: base.text }]}>{item.name}</Text>}
                    {showCount !== false && <Text style={[s.rowCount, { color: base.textFaint }]}>{item.songs.length} {item.songs.length === 1 ? 'track' : 'tracks'}</Text>}
                </View>
                {format === 'list_art' && minus ? <View style={{ marginLeft: 8 }}>{minus}</View> : (arrowOn && <Text style={[s.arrow, { color: base.textFaint }]}>›</Text>)}
            </DimPressable>
        </Animated.View>
    );
});

const COVER_MS = 350;       // hold this long and let go: the cover picker opens
const LIFT_MS = 500;        // hold this long: the playlist can be moved (iOS touch-and-hold)
const EDIT_LIFT_MS = 150;   // in edit mode a playlist can be grabbed almost at once
const EMPTY_HOLD_MS = 600;  // hold empty space to enter edit mode
const DRAG_SLOP = 6;        // points the finger must move after the lift to start a drag
const EDGE = 90;            // auto-scroll zone at the top and bottom of the list
const MAX_SCROLL = 14;      // px per frame at the very edge

export default function PlaylistsScreen() {
    const { playlists, covers: initialCovers, reload, reorderPlaylists } = useContext(LibraryContext);
    const { theme, base } = useTheme();
    const { playlistCoverShape, playlistCoverShadow, playlistCards, playlistArrow, topBarColor, ui, showPlaylistTrackCount, showPlaylistTitles } = usePreferences();
    const [hdrH, onHdrLayout] = useMeasuredHeight(TOP_PAD + 48 + TOP_FADE);
    const navigation = useNavigation();
    const [format, setFormat] = useState('list');
    // Real gap found here: this always started at {} and waited on its own
    // fresh getPlaylistCovers() fetch (below) to populate it — even on a
    // cold launch where App.js's prefetchPlaylistCovers() had already
    // resolved the exact same data (and warmed the actual image bytes)
    // moments earlier. Seeding from that already-known map means a cold
    // launch's first paint can show real covers immediately instead of
    // colored placeholders for a beat; the effects below still keep this
    // fresh afterward (a playlist-covers change elsewhere, or refocusing
    // this screen) exactly as before.
    const [covers, setCovers] = useState(initialCovers || {});
    // Covers are only swapped in once they are known to be changed, and after
    // the new pictures have been loaded (up to 0.6s), so a refresh (tab press,
    // a shrunk cover file, coming back to the app) never shows blank tiles
    // while a new file loads, and an unchanged set causes no redraw at all.
    const coversRef = useRef(covers);
    coversRef.current = covers;
    const applyCovers = useCallback(async (next) => {
        if (!next) return;
        const cur = coversRef.current || {};
        const keys = Object.keys(next);
        if (keys.length === Object.keys(cur).length && keys.every(k => next[k] === cur[k])) return;
        await Promise.race([
            Promise.all(Object.values(next).filter(Boolean).map(u => Image.prefetch(u).catch(() => { }))),
            new Promise(r => setTimeout(r, 600)),
        ]);
        setCovers(next);
    }, []);

    useEffect(() => { getPlaylistViewFormat().then(f => f && setFormat(f)); }, []);
    useEffect(() => { getPlaylistCovers().then(applyCovers); }, [playlists]);
    // iOS can drop decoded pictures from memory while the app is in the background, which is
    // the "covers sometimes reload" flash on coming back. Loading them again the moment the
    // app becomes active (before the list is looked at) puts them back in the image cache.
    useEffect(() => {
        const sub = AppState.addEventListener('change', (st) => {
            if (st !== 'active') return;
            Object.values(coversRef.current || {}).filter(Boolean).forEach(u => { Image.prefetch(u).catch(() => { }); });
        });
        return () => sub.remove();
    }, []);
    // Shrinks any older full-size covers once per launch, then refreshes.
    useEffect(() => {
        const t = setTimeout(() => {
            shrinkOldPlaylistCovers().then(changed => { if (changed) getPlaylistCovers().then(applyCovers); });
        }, 3000);
        return () => clearTimeout(t);
    }, []);
    useFocusEffect(useCallback(() => {
        getPlaylistCovers().then(applyCovers);
        // Picks up a layout change made elsewhere (Reset Playlist Screen in Settings).
        getPlaylistViewFormat().then(f => {
            if (!f) return;
            setFormat(prev => {
                if (prev === f) return prev;
                itemLayouts.current = [];
                return f;
            });
        });
        return () => { editRef.current = false; setEditMode(false); };
    }, []));

    const listOpacity = useRef(new Animated.Value(1)).current;

    const cycleFormat = async () => {
        const idx = FORMATS.findIndex(f => f.id === format);
        const next = FORMATS[(idx + 1) % FORMATS.length];
        Animated.timing(listOpacity, { toValue: 0, duration: 90, useNativeDriver: true }).start(() => {
            itemLayouts.current = [];
            setFormat(next.id);
            setPlaylistViewFormat(next.id);
            requestAnimationFrame(() => {
                Animated.timing(listOpacity, { toValue: 1, duration: 180, useNativeDriver: true }).start();
            });
        });
    };

    const isGrid = format.startsWith('grid');
    const numCols = FORMATS.find(f => f.id === format)?.cols ?? 1;
    
    // Pass the cover URI we already have in memory (from this screen's own
    // grid thumbnails) straight through as a nav param — see
    // PlaylistDetailScreen's own comment on why it used the initial state
    // for this instead of always starting from null and refetching. This
    // is exactly the "playlist cover has to load every time, should be
    // cached" report: the target screen's own Image.prefetch-before-render
    // fix already stopped the BLANK-FRAME flash, but every single open
    // still paid for a fresh AsyncStorage read + prefetch round trip before
    // the real cover could show at all — invisible on a fast connection to
    // fast storage, not so invisible on this setup. When we already know
    // the answer, hand it over directly instead of making the next screen
    // rediscover it from scratch.
    const openPlaylist = (item) => navigation.navigate('PlaylistDetail', { playlist: item, initialCover: covers[item.path] ?? null });
    const openPlaylistRef = useRef(openPlaylist);
    openPlaylistRef.current = openPlaylist;

    // ---- Hold and reorder (like iOS) -----------------------------------
    // Hold briefly and let go: menu (change / remove cover). Keep holding:
    // the playlist is picked up, drag it to a new spot and let go.
    const [editMode, setEditMode] = useState(false);
    const editRef = useRef(false);
    const pressingRef = useRef(false);
    const emptyHold = useRef({ timer: null, x: 0, y: 0, moved: false, onItem: false });
    const enterEdit = useCallback(() => { editRef.current = true; setEditMode(true); }, []);
    const exitEdit = useCallback(() => { editRef.current = false; setEditMode(false); }, []);
    const [activeIndex, setActiveIndex] = useState(-1);
    const [dragging, setDragging] = useState(false);
    const lift = useRef(new Animated.Value(1)).current;
    const animsRef = useRef({});
    const getAnim = (path) => (animsRef.current[path] || (animsRef.current[path] = new Animated.ValueXY()));
    const itemLayouts = useRef([]);
    const listRef = useRef(null);
    useScrollToTop(listRef);   // tapping the Playlists tab while already on this screen scrolls all the way up
    const listBoxRef = useRef(null);
    const scrollY = useRef(0);
    const scrollingRef = useRef(false);
    const viewH = useRef(0);
    const contentH = useRef(0);
    const timers = useRef({ cover: null, lift: null, pick: null, scroll: null, reset: null });
    const flags = useRef({ lifted: false, picked: false, captured: false, dropping: false });
    const drag = useRef({ active: false, from: -1, target: -1, slots: [], scroll0: 0, listTop: 0, fingerVY: 0, dx: 0, dy: 0, preDx: 0, preDy: 0 });
    const playlistsRef = useRef(playlists);
    playlistsRef.current = playlists;
    const numColsRef = useRef(numCols);
    numColsRef.current = numCols;

    const onItemLayout = useCallback((index, layout) => { itemLayouts.current[index] = layout; }, []);

    const getSlots = () => {
        const n = playlistsRef.current.length;
        const out = [];
        for (let i = 0; i < n; i++) {
            const it = itemLayouts.current[i];
            if (!it) return null;
            out.push({ cx: it.x + it.width / 2, cy: it.y + it.height / 2 });
        }
        return out;
    };

    const clearTimers = () => {
        clearTimeout(timers.current.cover); clearTimeout(timers.current.lift); clearTimeout(timers.current.pick);
        timers.current.cover = null; timers.current.lift = null; timers.current.pick = null;
    };
    const stopAutoScroll = () => { clearInterval(timers.current.scroll); timers.current.scroll = null; };

    // Puts a playlist back to normal (not lifted, not armed for dragging).
    const resetHold = () => {
        const d = drag.current;
        d.active = false;
        stopAutoScroll();
        flags.current = { lifted: false, picked: false, captured: false, dropping: flags.current.dropping };
        setDragging(false);
        setActiveIndex(-1);
        Animated.timing(lift, { toValue: 1, duration: 160, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    };

    const updateTarget = () => {
        const d = drag.current;
        const c0 = d.slots[d.from];
        const px = c0.cx + d.dx;
        const py = c0.cy + d.dy + (scrollY.current - d.scroll0);
        let best = d.target, bestDist = Infinity;
        for (let j = 0; j < d.slots.length; j++) {
            const dist = (d.slots[j].cx - px) ** 2 + (d.slots[j].cy - py) ** 2;
            if (dist < bestDist) { bestDist = dist; best = j; }
        }
        if (best === d.target) return;
        d.target = best;
        const list = playlistsRef.current;
        for (let i = 0; i < list.length; i++) {
            if (i === d.from) continue;
            let slot = i;
            if (d.from < best && i > d.from && i <= best) slot = i - 1;
            else if (d.from > best && i >= best && i < d.from) slot = i + 1;
            Animated.timing(getAnim(list[i].path), {
                toValue: { x: d.slots[slot].cx - d.slots[i].cx, y: d.slots[slot].cy - d.slots[i].cy },
                duration: 240, easing: Easing.out(Easing.cubic), useNativeDriver: true,
            }).start();
        }
    };

    const applyDrag = () => {
        const d = drag.current;
        if (!d.active) return;
        getAnim(playlistsRef.current[d.from].path).setValue({ x: d.dx, y: d.dy + (scrollY.current - d.scroll0) });
        updateTarget();
    };

    // First stage of a hold (a bit under half a second): the playlist lifts.
    // Letting go now opens the cover picker.
    // A finger that has started scrolling the list never lifts a playlist (that stopped the scroll dead and
    // then made the playlist jump to the finger).
    const scrolledSincePress = () => scrollingRef.current || Math.abs(scrollY.current - pressScrollY.current) > 3;
    const coverReady = (index) => {
        if (scrolledSincePress()) return;
        flags.current.lifted = true;
        setActiveIndex(index);
        Animated.spring(lift, { toValue: 1.05, friction: 8, tension: 170, useNativeDriver: true }).start();
    };
    // Second stage (half a second, like iOS): the playlist can be moved. From
    // here a finger movement starts a drag; letting go in place still opens
    // the cover picker.
    const liftUp = (index) => {
        if (scrolledSincePress()) return;
        if (!flags.current.lifted) coverReady(index);
        const slots = getSlots();
        if (!slots || slots.length < 2) return;   // nothing to reorder: stays a cover hold
        const d = drag.current;
        d.active = true; d.from = index; d.target = index; d.slots = slots;
        d.scroll0 = scrollY.current; d.dx = 0; d.dy = 0; d.preDx = 0; d.preDy = 0; d.fingerVY = -1;
        if (listBoxRef.current) listBoxRef.current.measureInWindow((x, y) => { d.listTop = y; });
        setDragging(true);   // the list stops scrolling under the held finger
        stopAutoScroll();
        timers.current.scroll = setInterval(() => {
            if (!drag.current.active || !flags.current.picked || drag.current.fingerVY < 0) return;
            const fy = drag.current.fingerVY;
            let v = 0;
            if (fy < EDGE) v = -((EDGE - fy) / EDGE) * MAX_SCROLL;
            else if (fy > viewH.current - EDGE) v = ((fy - (viewH.current - EDGE)) / EDGE) * MAX_SCROLL;
            if (!v) return;
            const maxY = Math.max(0, contentH.current - viewH.current);
            const ny = Math.max(0, Math.min(maxY, scrollY.current + v));
            if (ny === scrollY.current) return;
            scrollY.current = ny;
            if (listRef.current) listRef.current.scrollTo({ y: ny, animated: false });
            applyDrag();
        }, 16);
    };

    const endDrag = () => {
        const d = drag.current;
        if (!d.active) return;
        d.active = false;
        stopAutoScroll();
        flags.current.dropping = true;
        const list = playlistsRef.current;
        const from = d.from, target = d.target;
        const moved = target !== from;
        const dragged = getAnim(list[from].path);
        const toValue = moved
            ? { x: d.slots[target].cx - d.slots[from].cx, y: d.slots[target].cy - d.slots[from].cy }
            : { x: 0, y: 0 };
        Animated.parallel([
            Animated.timing(dragged, { toValue, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
            Animated.timing(lift, { toValue: 1, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        ]).start(() => {
            if (moved) {
                const next = [...list];
                const [it] = next.splice(from, 1);
                next.splice(target, 0, it);
                persistOrder(next);
            }
            flags.current = { lifted: false, picked: false, captured: false, dropping: false };
            setDragging(false);
            setActiveIndex(-1);
            if (!moved) Object.values(animsRef.current).forEach(a => a.setValue({ x: 0, y: 0 }));
        });
    };

    // The new order is on screen: now every playlist can drop its temporary
    // offset (they already sit in their new slots, so nothing visibly moves).
    // Also when the layout is switched: a playlist still carrying an offset from a drag showed up shifted in
    // the new layout.
    useLayoutEffect(() => {
        Object.values(animsRef.current).forEach(a => { a.stopAnimation(); a.setValue({ x: 0, y: 0 }); });
    }, [format]);
    const orderKey = playlists.map(p => p.path).join('|');
    useLayoutEffect(() => {
        Object.values(animsRef.current).forEach(a => a.setValue({ x: 0, y: 0 }));
    }, [orderKey]);

    // The press/drag handlers below are created once, so they reach the
    // current versions of these functions through this ref.
    const latest = useRef({});
    const pressScrollY = useRef(0);
    const pressIn = useCallback((item, index) => {
        clearTimers();
        pressScrollY.current = scrollY.current;
        scrollingRef.current = false;   // a touch stops any scrolling that was still coasting
        clearTimeout(timers.current.reset);
        if (drag.current.active || flags.current.dropping) return;
        flags.current = { lifted: false, picked: false, captured: false, dropping: false };
        pressingRef.current = true;
        emptyHold.current.onItem = true;
        // The cover picker is ready a little sooner than moving is. In edit
        // mode both happen after a tenth of a second.
        if (!editRef.current) timers.current.cover = setTimeout(() => latest.current.coverReady(index), COVER_MS);
        timers.current.lift = setTimeout(() => latest.current.liftUp(index), editRef.current ? EDIT_LIFT_MS : LIFT_MS);
    }, []);

    const pressOut = useCallback(() => {
        pressingRef.current = false;
        clearTimers();
        if (flags.current.captured) return;   // being dragged: the drag handler finishes it
        // A real release runs onPress right after this in the same tick (it
        // reads the flags first). A cancelled touch (a scroll took over)
        // never gets onPress, so this puts the row back to normal.
        clearTimeout(timers.current.reset);
        timers.current.reset = setTimeout(() => { if (!flags.current.captured && !flags.current.dropping) latest.current.resetHold(); }, 0);
    }, []);

    const pressRelease = useCallback((item) => {
        if (flags.current.dropping) return;
        if (flags.current.captured) { latest.current.endDrag(); return; }
        if (flags.current.lifted) {
            // Held, then let go without dragging: pick a new cover.
            clearTimeout(timers.current.reset);
            latest.current.resetHold();
            latest.current.changeCover(item);
            return;
        }
        if (editRef.current) { latest.current.changeCover(item); return; }   // edit mode: a tap picks a cover
        openPlaylistRef.current(item);
    }, []);

    const pan = useRef(PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        // Only after the item has lifted: moving the finger more than a few
        // points takes over from the list and starts the drag.
        onMoveShouldSetPanResponderCapture: (e, g) => {
            const d = drag.current;
            if (!d.active) return false;
            if (flags.current.captured) return true;
            if (Math.hypot(g.dx, g.dy) > DRAG_SLOP) {
                flags.current.captured = true;
                d.preDx = g.dx; d.preDy = g.dy;
                return true;
            }
            return false;
        },
        onPanResponderGrant: () => {
            flags.current.picked = true;
            // Dragging a playlist is what puts the screen into edit mode.
            if (!editRef.current) { editRef.current = true; setEditMode(true); }
            Animated.spring(lift, { toValue: 1.08, friction: 7, tension: 170, useNativeDriver: true }).start();
        },
        onPanResponderTerminationRequest: () => false,
        onPanResponderMove: (e, g) => {
            const d = drag.current;
            d.dx = d.preDx + g.dx; d.dy = d.preDy + g.dy; d.fingerVY = g.moveY - d.listTop;
            latest.current.applyDrag();
        },
        onPanResponderRelease: () => latest.current.endDrag(),
        onPanResponderTerminate: () => latest.current.endDrag(),
    })).current;

    useEffect(() => () => { clearTimers(); stopAutoScroll(); clearTimeout(timers.current.reset); clearTimeout(emptyHold.current.timer); }, []);

    const persistOrder = async (newList) => {
        // Reordering only needs to persist the small order list and update
        // what's on screen — it doesn't change anything about the songs or
        // playlists themselves. This used to call the same full reload()
        // used after a real library change, which re-scans the whole music
        // folder from disk AND re-prefetches every playlist's cover image,
        // just to reflect a reorder. That's what made "Move Up/Down/Top/
        // Bottom" feel slow to respond.
        setPlaylistOrder(newList.map(p => p.path));
        reorderPlaylists(newList);
    };

    // Asks before removing a cover. The first call (press down) only marks the
    // touch as being on a playlist, so it is not read as a tap on empty space.
    // useCallback: PlaylistRow is memoized so a drag/edit doesn't re-render
    // every visible row, and a fresh function here every render defeated that
    // completely, every row (and its running wiggle animation) re-rendered on
    // every parent state change, which is the choppiness while reordering.
    const removeCoverAsk = useCallback((item, down) => {
        if (down) { emptyHold.current.onItem = true; return; }
        Alert.alert(
            'Remove cover picture?',
            `"${item.name}" will go back to a blank cover.`,
            [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Yes, remove', style: 'destructive', onPress: async () => { setCovers(await setPlaylistCover(item.path, null)); } },
            ]
        );
    }, []);

    const changeCover = async (item) => {
        const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!perm.granted) {
            Alert.alert('Permission needed', 'Allow Photos access in Settings to set a playlist cover.');
            return;
        }
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [1, 1],
            // Same as PlaylistDetailScreen's own cover picker — see its
            // comment.
            quality: 0.4,
        });
        if (result.canceled || !result.assets?.[0]?.uri) return;
        const permanentUri = await persistCoverImage(result.assets[0].uri, 600);
        // Real gap found here: App.js's reload() prefetches every playlist
        // cover, but only the ones already saved at COLD START — a cover
        // set or changed mid-session (right here) never went through
        // Image.prefetch at all, so its first paint (this row re-rendering
        // with the new uri right below) always decoded fresh from disk.
        // That's "sometimes the playlist covers [aren't cached]" — it was
        // never about the covers that existed at launch, only ones changed
        // during the session. Same wait-before-render reasoning as reload()
        // itself: awaiting this (not fire-and-forget) means the image is
        // actually in cache by the time setCovers below triggers the render.
        await Image.prefetch(permanentUri).catch(() => { });
        const next = await setPlaylistCover(item.path, permanentUri);
        setCovers(next);
    };

    latest.current = { coverReady, liftUp, endDrag, resetHold, applyDrag, changeCover };

    // A playlist swiped away from somewhere other than the edge moves itself (not the stack), and shares how far it has
    // gone in playlistBackX. The stack leaves this screen pushed 30 percent to the left while a playlist is open; this
    // takes that shift back at the same pace, so the screen slides in from the left exactly as it does for an edge swipe.
    // It is 0 at all other times.
    const backSwipeShift = useMemo(() => playlistBackX.interpolate({ inputRange: [0, 10000], outputRange: [0, 3000], extrapolate: 'clamp' }), []);
    return (
        <Animated.View style={{ flex: 1, transform: [{ translateX: backSwipeShift }] }}>
        <ScreenBackground style={s.container}>
            <StatusBar barStyle="light-content" />
            {/* Same top row as All Songs and the Player: title where the back
                arrow sits, buttons in the exact same top-right spots as EQ
                and queue (same sizes, same gap, same top padding). */}
            <View style={[s.header, !topBarColor && OVERLAY_HEADER]} pointerEvents={topBarColor ? 'auto' : 'box-none'} onLayout={onHdrLayout}>
                {topBarColor && <TopBarBack color={base.surface} />}
                {/* While rearranging, a tap anywhere on the top bar is "Done" too. */}
                {editMode ? <Pressable style={StyleSheet.absoluteFill} onPress={exitEdit} /> : null}
                <Text style={[s.title, { color: base.text, flex: 1, marginLeft: 16 }]}>Playlists</Text>
                {editMode ? (
                    <TouchableOpacity onPress={exitEdit} style={s.doneBtn} hitSlop={HIT}>
                        <Text style={[s.doneText, { color: theme.accent }]}>Done</Text>
                    </TouchableOpacity>
                ) : (
                    <View style={{ flexDirection: 'row', gap: 6 }}>
                        {ui.pl_layout !== false && (
                            <TouchableOpacity onPress={cycleFormat} style={s.btn} hitSlop={HIT}>
                                <FormatIcon id={format} color={theme.accent} />
                            </TouchableOpacity>
                        )}
                        {ui.pl_reload !== false && (
                            <TouchableOpacity onPress={reload} style={s.btn} hitSlop={HIT}>
                                <Text style={[s.btnText, { color: theme.accent }]}>↻</Text>
                            </TouchableOpacity>
                        )}
                    </View>
                )}
            </View>
            {playlists.length === 0 ? (
                <View style={s.empty}>
                    <Text style={[s.emptyTitle, { color: base.text }]}>No playlists yet</Text>
                    <Text style={[s.emptyText, { color: base.textFaint }]}>Add folders to your music folder{'\n'}(Settings → Music & Library shows where),{'\n'}or use Import Songs</Text>
                </View>
            ) : (
                <Animated.View style={{ flex: 1, opacity: listOpacity, marginTop: topBarColor ? -TOP_FADE : 0 }}>
                    <View
                        ref={listBoxRef}
                        style={{ flex: 1 }}
                        onLayout={(e) => { viewH.current = e.nativeEvent.layout.height; }}
                        onTouchStart={(e) => {
                            const eh = emptyHold.current;
                            clearTimeout(eh.timer);
                            eh.moved = false;
                            if (e.nativeEvent.touches.length > 1) return;
                            eh.x = e.nativeEvent.pageX; eh.y = e.nativeEvent.pageY;
                            if (editRef.current) return;
                            // A touch on a playlist is handled by the playlist itself; this
                            // only fires when the finger is on empty space.
                            eh.timer = setTimeout(() => {
                                if (!pressingRef.current && !drag.current.active && !flags.current.lifted) enterEdit();
                            }, EMPTY_HOLD_MS);
                        }}
                        onTouchMove={(e) => {
                            const eh = emptyHold.current;
                            if (Math.hypot(e.nativeEvent.pageX - eh.x, e.nativeEvent.pageY - eh.y) > 10) {
                                eh.moved = true;
                                if (eh.timer) { clearTimeout(eh.timer); eh.timer = null; }
                            }
                        }}
                        onTouchEnd={() => {
                            const eh = emptyHold.current;
                            clearTimeout(eh.timer);
                            // Edit mode: a plain tap on empty space is "Done".
                            if (editRef.current && !eh.moved && !eh.onItem && !drag.current.active && !flags.current.dropping) exitEdit();
                            eh.onItem = false;
                        }}
                        onTouchCancel={() => { clearTimeout(emptyHold.current.timer); emptyHold.current.onItem = false; }}
                        {...pan.panHandlers}
                    >
                    <ScrollView
                        ref={listRef}
                        key={format}
                        scrollEnabled={!dragging}
                        scrollEventThrottle={16}
                        onScroll={(e) => { scrollY.current = e.nativeEvent.contentOffset.y; }}
                        onScrollBeginDrag={() => { scrollingRef.current = true; if (!drag.current.active) clearTimers(); }}
                        onScrollEndDrag={(e) => { const v = e.nativeEvent.velocity; if (!v || Math.abs(v.y) < 0.05) scrollingRef.current = false; }}
                        onMomentumScrollBegin={() => { scrollingRef.current = true; }}
                        onMomentumScrollEnd={() => { scrollingRef.current = false; }}
                        onContentSizeChange={(w, h) => { contentH.current = h; }}
                        // Grid cells get their spacing from each cell's own margins, so the container adds no
                        // extra top gap beyond the header.
                        contentContainerStyle={[{ paddingTop: topBarColor ? TOP_FADE : hdrH, paddingBottom: 150, paddingHorizontal: isGrid ? GRID_PADDING : 0 }, isGrid && { flexDirection: 'row', flexWrap: 'wrap' }]}
                    >
                        {playlists.map((item, index) => (
                            <PlaylistRow
                                key={item.path}
                                item={item}
                                index={index}
                                format={format}
                                numCols={numCols}
                                cover={covers[item.path]}
                                base={base}
                                shape={playlistCoverShape}
                                cardOn={playlistCards}
                                arrowOn={playlistArrow}
                                shadowOn={playlistCoverShadow}
                                showTitle={showPlaylistTitles}
                                showCount={showPlaylistTrackCount}
                                isActive={index === activeIndex}
                                isDragging={dragging}
                                editing={editMode}
                                anim={getAnim(item.path)}
                                lift={lift}
                                onItemLayout={onItemLayout}
                                onPressIn={pressIn}
                                onPressOut={pressOut}
                                onPress={pressRelease}
                                onRemoveCover={removeCoverAsk}
                            />
                        ))}
                    </ScrollView>
                    </View>
                </Animated.View>
            )}

        </ScreenBackground>
        </Animated.View>
    );
}

const HIT = { top: 14, bottom: 14, left: 14, right: 14 };

const s = StyleSheet.create({
    container: { flex: 1 },
    lifted: { shadowColor: '#000', shadowOpacity: 0.55, shadowRadius: 14, shadowOffset: { width: 0, height: 8 }, elevation: 12 },
    // Round 39 trimmed this to 44 to fix "excess fat above the covers" —
    // wrong lever. That gap was actually gridItem's own padding/background
    // (see below, fixed this round), not header height. 44 just made this
    // screen's title sit noticeably higher than All Songs/Settings (both
    // paddingTop:60) and Playlist Detail (56) — restored to match.
    header: { flexDirection: 'row', alignItems: 'center', paddingTop: TOP_PAD, paddingHorizontal: 8, paddingBottom: 8 + TOP_FADE, zIndex: 5, minHeight: TOP_PAD + 40 + 8 + TOP_FADE },
    title: { color: '#e5e5e5', fontSize: 28, fontWeight: '700' },
    btn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
    btnText: { fontSize: 28, lineHeight: 34, fontWeight: '600' },
    doneBtn: { height: 40, paddingHorizontal: 12, justifyContent: 'center', alignItems: 'center' },
    doneText: { fontSize: 17, fontWeight: '700' },
    empty: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 40 },
    emptyTitle: { color: '#e5e5e5', fontSize: 18, fontWeight: '600', marginBottom: 12 },
    emptyText: { color: '#555', fontSize: 14, textAlign: 'center', lineHeight: 22 },
    row: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 14, marginVertical: 3, paddingVertical: 16, paddingHorizontal: 16, backgroundColor: '#0f0f0f', borderRadius: 14, minHeight: 68 },
    listArt: { width: 44, height: 44, marginRight: 12 },
    rowName: { color: '#e5e5e5', fontSize: 16, fontWeight: '500' },
    rowCount: { color: '#555', fontSize: 12, marginTop: 3 },
    arrow: { color: '#333', fontSize: 22 },
    // Real cause of the "extra base color stuff above each cover" (his
    // yellow-circled screenshot): this had its own padding:8 + a solid
    // #0f0f0f card background wrapping the art, while gridArt inside it was
    // ALSO set to the full cell `size` — so the art box was actually wider
    // than the padded space it sat in, overflowing the card and reading as
    // a visible dark band peeking out around/above the actual cover image.
    // No padding/background here now — the cell is just a layout box, the
    // cover image is the only visible surface.
    gridItem: { borderRadius: 14, alignItems: 'center' },
    gridArt: { justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
    card: { position: 'absolute' },
    minus: { position: 'absolute', top: -6, right: -6, width: 24, height: 24, borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, alignItems: 'center', justifyContent: 'center', zIndex: 5 },
    minusBar: { width: 12, height: 2.5, borderRadius: 1.25 },
    gridName: { color: '#e5e5e5', fontSize: 13, fontWeight: '600', textAlign: 'center' },
    gridCount: { color: '#555', fontSize: 11, marginTop: 3 },
    menuTitle: { color: '#555', fontSize: 13, fontWeight: '600', textAlign: 'center', marginBottom: 8, paddingHorizontal: 20 },
    menuRow: { paddingVertical: 16, borderTopWidth: 1, borderTopColor: '#1a1a1a', paddingHorizontal: 20 },
    menuRowText: { color: '#e5e5e5', fontSize: 16, textAlign: 'center' },
});
