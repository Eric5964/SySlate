import { useEffect, useRef, useState } from 'react';
import { InteractionManager } from 'react-native';
import { extractEmbeddedArt, getCachedArtFast, peekCachedArtBulk, listArtUri, subscribeArtUpdates } from '../utils/embeddedArt';

// Returns { songId: uri | null } for whichever songs have resolved so far.
//
// Genuinely new (uncached) extractions are capped per run — a large library
// with this setting on could otherwise background-process thousands of
// songs unboundedly in one sweep, which is real sustained CPU pressure.
// Lowered from 150 after a confirmed CPU-limit kill (crash log showed flat
// memory, pure CPU-time violation) — a big library doing this many
// extractions back to back, even staggered, was too much sustained work in
// one run. Cached lookups don't count against the cap.
const MAX_NEW_EXTRACTIONS_PER_RUN = 60;
// How many genuinely new extractions one 6s sweep tick may do once the first
// pass has run out (see the sweep at the bottom of the effect).
const SWEEP_EXTRACTIONS = 20;
const FLUSH_BATCH_SIZE = 20;
const YIELD_EVERY = 20;

// Real cause of "covers still need to load often" / flashing placeholders:
// artMap lived only in each hook instance's own useState, so every screen
// or list that mounted (opening a playlist, switching tabs, opening the
// queue) started from an EMPTY map and had to re-resolve every row before
// showing a single cover, even though the same songs had already been
// resolved moments earlier by a different instance. Resolved results now
// also live in this module-level map for the whole app session, and every
// new instance starts from it, so a cover that's been found once shows on
// first render everywhere after.
const SESSION_ART = {};

// The rows that are on screen right now (the lists report them). Their covers are fetched first and a few at a
// time, instead of waiting their turn in list order behind hundreds of rows nobody is looking at.
let VISIBLE = new Set();
const visibleSubs = new Set();
export function setVisibleArtIds(ids) {
    VISIBLE = new Set(ids);
    visibleSubs.forEach(f => { try { f(); } catch { } });
}
const VISIBLE_PARALLEL = 3;
const VISIBLE_MAX = 16;

export function useListArt(songs, enabled) {
    // Starts from everything already known (this session's results plus the
    // on-disk cover cache, read synchronously), so a list's first paint
    // already has its covers instead of filling in over the next second.
    const [artMap, setArtMap] = useState(() => (enabled ? { ...SESSION_ART, ...peekCachedArtBulk(songs) } : {}));
    const runIdRef = useRef(0);

    useEffect(() => {
        if (!enabled || !songs?.length) return;
        const runId = ++runIdRef.current;
        let cancelled = false;
        let pending = {};
        let pendingCount = 0;
        const resolved = new Set();

        const flush = () => {
            if (pendingCount === 0) return;
            const batch = pending;
            pending = {};
            pendingCount = 0;
            for (const id of Object.keys(batch)) batch[id] = listArtUri(batch[id]);
            Object.assign(SESSION_ART, batch);
            setArtMap(prev => ({ ...prev, ...batch }));
        };

        const isStale = () => cancelled || runIdRef.current !== runId;

        // Phase 1: restore anything already cached, immediately, with no
        // delay. This used to be gated behind the same InteractionManager
        // + 300ms guard as the heavy extraction pass below, which meant
        // covers already found would still vanish and take ~300ms+ to
        // reappear every time this screen remounted (e.g. leaving and
        // re-entering a playlist). A cache hit is cheap — one AsyncStorage
        // lookup, no file I/O — so there's no reason to delay it.
        const runCacheOnly = async () => {
            // Fast pass: everything the in-memory cache already knows, in one
            // go and one state update.
            const bulk = peekCachedArtBulk(songs);
            for (const id of Object.keys(bulk)) {
                if (resolved.has(id)) continue;
                resolved.add(id);
                pending[id] = bulk[id];
                pendingCount++;
            }
            flush();
            let checked = 0;
            for (const song of songs) {
                if (isStale()) return;
                if (resolved.has(song.id)) continue;
                try {
                    const cached = await getCachedArtFast(song);
                    if (isStale()) return;
                    if (cached !== undefined) {
                        resolved.add(song.id);
                        pending[song.id] = cached;
                        pendingCount++;
                        if (pendingCount >= FLUSH_BATCH_SIZE) flush();
                    }
                } catch { }
                // A long uninterrupted loop of hundreds of these back to
                // back can still add up to a real blocking stretch on the
                // JS thread even though each individual check is cheap —
                // this yields periodically so it can't be the thing making
                // a gesture/animation stutter elsewhere in the app.
                if (++checked % YIELD_EVERY === 0) await new Promise(r => setTimeout(r, 0));
            }
            flush();
        };

        // Phase 2: genuinely new extractions — real file I/O — stay behind
        // the interaction/settle delay so they don't compete with
        // navigation transitions on the JS thread.
        const runNewExtractions = async (maxCount = MAX_NEW_EXTRACTIONS_PER_RUN) => {
            let newExtractions = 0;
            for (const song of songs) {
                if (isStale()) break;
                if (resolved.has(song.id)) continue;
                if (newExtractions >= maxCount) break;
                newExtractions++;
                try {
                    const uri = await extractEmbeddedArt(song);
                    if (isStale()) break;
                    resolved.add(song.id);
                    pending[song.id] = uri;
                    pendingCount++;
                } catch { }
                if (pendingCount >= FLUSH_BATCH_SIZE) flush();
                await new Promise(r => setTimeout(r, 60));
            }
            flush();
        };

        runCacheOnly();

        // Visible rows first: a few extractions at once, no stagger, without waiting for the settle delay.
        let visBusy = false, visAgain = false, visTimer = null;
        const extractVisible = async () => {
            if (visBusy) { visAgain = true; return; }
            visBusy = true;
            try {
                do {
                    visAgain = false;
                    const todo = songs.filter(sg => VISIBLE.has(sg.id) && !resolved.has(sg.id)).slice(0, VISIBLE_MAX);
                    for (let i = 0; i < todo.length; i += VISIBLE_PARALLEL) {
                        if (isStale()) return;
                        await Promise.all(todo.slice(i, i + VISIBLE_PARALLEL).map(async (song) => {
                            try {
                                const uri = await extractEmbeddedArt(song);
                                if (isStale()) return;
                                resolved.add(song.id);
                                pending[song.id] = uri;
                                pendingCount++;
                            } catch { }
                        }));
                        flush();
                    }
                } while (visAgain && !isStale());
            } finally { visBusy = false; }
        };
        const onVisible = () => { clearTimeout(visTimer); visTimer = setTimeout(extractVisible, 120); };
        visibleSubs.add(onVisible);
        onVisible();

        const cancelRef = { current: null };
        const handle = InteractionManager.runAfterInteractions(() => {
            const t = setTimeout(runNewExtractions, 300);
            cancelRef.current = () => clearTimeout(t);
        });
        cancelRef.current = () => handle.cancel();

        // While this screen stays mounted, periodically re-check for
        // anything that got resolved by someone ELSE — mainly the
        // currently-playing track's own prefetch-ahead in PlaybackContext,
        // which writes into the same shared disk cache but has no way to
        // tell an already-open list screen "hey, I found one." Without
        // this, art that appeared in the background only ever showed up
        // the next time the screen remounted (leaving and re-entering the
        // playlist), which is what made it look like it only refreshed on
        // exit/re-entry, and left coverage looking arbitrarily scattered
        // depending on exactly when you happened to leave and come back.
        // Cheap — every check here is a plain object lookup against the
        // cache already held in memory, no file I/O. Stops on its own once
        // nothing's left to resolve.
        const sweepInterval = setInterval(() => {
            if (isStale()) { clearInterval(sweepInterval); return; }
            if (resolved.size >= songs.length) { clearInterval(sweepInterval); return; }
            // Cache-only was not enough on its own: the one extraction pass
            // above stops after MAX_NEW_EXTRACTIONS_PER_RUN, so in a list with
            // more uncached covers than that, everything past that point kept
            // a blank placeholder until the screen was left and re-entered.
            // A small batch per sweep keeps the same per-run budget while
            // actually finishing the list (and lets the interval stop on its
            // own once everything has been tried).
            runCacheOnly().then(() => {
                if (!isStale() && resolved.size < songs.length) runNewExtractions(SWEEP_EXTRACTIONS);
            });
        }, 6000);

        // A large cover found at the end of loading: show it on the rows that are open right now.
        const idsHere = new Set(songs.map(x => x.id));
        const unsubscribe = subscribeArtUpdates((id, uri) => {
            if (isStale() || !idsHere.has(id)) return;
            SESSION_ART[id] = uri;
            setArtMap(prev => ({ ...prev, [id]: uri }));
        });

        return () => { cancelled = true; cancelRef.current?.(); clearInterval(sweepInterval); unsubscribe(); visibleSubs.delete(onVisible); clearTimeout(visTimer); };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [enabled, songs]);

    return artMap;
}
