import React from 'react';
import { View, Animated } from 'react-native';

// Pure-CSS/View icons — no emoji, no SVG library dependency.
// Sizes are the visual bounding box; colors passed as `color`.

export function PlayIcon({ size = 22, color = '#fff', style }) {
    return (
        <View style={[{
            width: 0, height: 0,
            borderTopWidth: size * 0.5,
            borderBottomWidth: size * 0.5,
            borderLeftWidth: size * 0.82,
            borderTopColor: 'transparent',
            borderBottomColor: 'transparent',
            borderLeftColor: color,
            marginLeft: size * 0.14,
        }, style]} />
    );
}

export function PauseIcon({ size = 22, color = '#fff', style }) {
    const barW = Math.round(size * 0.28);
    const gap = Math.round(size * 0.18);
    return (
        <View style={[{ flexDirection: 'row', width: size, height: size, alignItems: 'center', justifyContent: 'center' }, style]}>
            <View style={{ width: barW, height: size * 0.86, borderRadius: 2, backgroundColor: color, marginRight: gap }} />
            <View style={{ width: barW, height: size * 0.86, borderRadius: 2, backgroundColor: color }} />
        </View>
    );
}

export function SkipNextIcon({ size = 26, color = '#ccc', style }) {
    return (
        <View style={[{ flexDirection: 'row', alignItems: 'center', width: size, height: size, justifyContent: 'center' }, style]}>
            <View style={{
                width: 0, height: 0,
                borderTopWidth: size * 0.32,
                borderBottomWidth: size * 0.32,
                borderLeftWidth: size * 0.5,
                borderTopColor: 'transparent',
                borderBottomColor: 'transparent',
                borderLeftColor: color,
            }} />
            <View style={{ width: size * 0.09, height: size * 0.64, backgroundColor: color, borderRadius: 1, marginLeft: size * 0.06 }} />
        </View>
    );
}

export function SkipPrevIcon({ size = 26, color = '#ccc', style }) {
    return (
        <View style={[{ flexDirection: 'row', alignItems: 'center', width: size, height: size, justifyContent: 'center' }, style]}>
            <View style={{ width: size * 0.09, height: size * 0.64, backgroundColor: color, borderRadius: 1, marginRight: size * 0.06 }} />
            <View style={{
                width: 0, height: 0,
                borderTopWidth: size * 0.32,
                borderBottomWidth: size * 0.32,
                borderRightWidth: size * 0.5,
                borderTopColor: 'transparent',
                borderBottomColor: 'transparent',
                borderRightColor: color,
            }} />
        </View>
    );
}

export function ShuffleIcon({ size = 22, color = '#333', style }) {
    // Simplified back down per feedback — the crossing-arrows version was
    // "less minimalistic, more complicated" than wanted. Back to an X, but
    // squashed (shallower angle, shorter bars) rather than a full 45°
    // symmetric X, so it still reads distinctly from a close/cancel button.
    // Explicit top/left instead of relying on the parent's
    // alignItems/justifyContent to center these — absolutely-positioned
    // children honoring flex alignment is inconsistent across RN versions,
    // which is why the two bars weren't crossing exactly at center (visibly
    // lopsided/"not smooth" up close).
    const bar = size * 0.72;
    // The same line weight as LoopIcon's ring (they sit side by side in the Player): was a fixed 2,
    // the ring is size x 0.11 (about 4 at the Player's size).
    const bw = Math.max(2, size * 0.11);
    return (
        <View style={[{ width: size, height: size }, style]}>
            <Animated.View style={{ position: 'absolute', top: size / 2 - bw / 2, left: (size - bar) / 2, width: bar, height: bw, backgroundColor: color, borderRadius: bw / 2, transform: [{ rotate: '22deg' }] }} />
            <Animated.View style={{ position: 'absolute', top: size / 2 - bw / 2, left: (size - bar) / 2, width: bar, height: bw, backgroundColor: color, borderRadius: bw / 2, transform: [{ rotate: '-22deg' }] }} />
        </View>
    );
}

export function LoopIcon({ size = 22, color = '#333', single = false, style }) {
    // Simplified back down per feedback, same as ShuffleIcon above — a
    // plain ring ("O") instead of the gapped-ring-plus-arrowhead version.
    // The "1" badge (repeat-one specifically) is the only thing that isn't
    // pure decoration, so it stays.
    const ring = size * 0.72;
    const bw = Math.max(2, size * 0.11);
    return (
        <View style={[{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }, style]}>
            <Animated.View style={{ width: ring, height: ring, borderRadius: ring / 2, borderWidth: bw, borderColor: color }} />
            {single && (
                <Animated.Text style={{ position: 'absolute', bottom: -2, right: -4, fontSize: size * 0.42, fontWeight: '800', color }}>1</Animated.Text>
            )}
        </View>
    );
}

export function AddQueueIcon({ size = 20, color = '#fff', style }) {
    return (
        <View style={[{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }, style]}>
            <View style={{ position: 'absolute', width: size * 0.8, height: 2, backgroundColor: color, borderRadius: 1 }} />
            <View style={{ position: 'absolute', width: 2, height: size * 0.8, backgroundColor: color, borderRadius: 1 }} />
        </View>
    );
}

export function MenuBarsIcon({ size = 26, color = '#fff', style }) {
    const barH = Math.max(2, Math.round(size * 0.09));
    const gap = Math.round(size * 0.2);
    return (
        <View style={[{ width: size, justifyContent: 'center' }, style]}>
            <View style={{ height: barH, borderRadius: 1, backgroundColor: color, marginBottom: gap }} />
            <View style={{ height: barH, borderRadius: 1, backgroundColor: color, marginBottom: gap }} />
            <View style={{ height: barH, borderRadius: 1, backgroundColor: color }} />
        </View>
    );
}

export function TrashIcon({ size = 20, color = '#fff', style }) {
    return (
        <View style={[{ width: size, height: size, alignItems: 'center', justifyContent: 'flex-start' }, style]}>
            <View style={{ width: size * 0.7, height: 2, backgroundColor: color, borderRadius: 1, marginBottom: 2 }} />
            <View style={{ width: size * 0.5, height: size * 0.6, borderWidth: 2, borderTopWidth: 0, borderColor: color, borderBottomLeftRadius: 3, borderBottomRightRadius: 3 }} />
        </View>
    );
}

export function MoonIcon({ size = 20, color = '#fff', style }) {
    // Was two overlapping circles with a translucent black "cutout" —
    // the only icon in this file relying on background showing through a
    // semi-transparent fill instead of pure solid geometry. That reads as a
    // muddy smudge rather than a crisp crescent depending on what's behind
    // it (a photo background, a lighter theme, etc.), unlike every other
    // icon here. Rebuilt as an open ring (same technique as LoopIcon's "O"),
    // so the gap is genuinely transparent — whatever's behind it just shows
    // through unaltered, the same way the middle of LoopIcon's ring does.
    const bw = Math.max(2, size * 0.17);
    return (
        <View style={[{ width: size, height: size }, style]}>
            <View style={{
                width: size, height: size, borderRadius: size / 2, borderWidth: bw,
                borderColor: color, borderRightColor: 'transparent', borderBottomColor: 'transparent',
                transform: [{ rotate: '135deg' }],
            }} />
        </View>
    );
}
